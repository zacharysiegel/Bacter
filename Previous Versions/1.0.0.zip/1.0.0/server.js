/*
NPM Version: 5.6.0
	Update npm code: <npm install npm@latest -g>
Node.js Version: 9.3.0
*/

/* 
socket.emit('ID', data) // Emit to specific client
socket.broadcast.emit('ID', data); // Emit to all other clients
io.sockets.emit('ID', data); // Emit to all clients

socket.on('ID', function(parameter) {});
*/

// Express
var port = 80;
var express = require('express');
var app = express();
var server = app.listen(port);

// Socket.io
var socketio = require('socket.io');
var io = socketio(server);

// Send Static Data
app.use(express.static('./www'));

// Start
var connections = 0;
io.sockets.on('connection', newConnection);
var games = [
	// {
		// players: [], 
		// info: {}, 
		// world: {},  
		// orgs: []
	// }
];
var intervals = [];

console.log('Running...');
console.log('');
console.log('Connections: ' + connections);

//////////////////////////////////////////////////////////////

// New Connection
function newConnection(sockeT) {
	// Connect
	connections++;
	console.log('Client connected: ' + sockeT.id); // Server Message
	console.log('Connections: ' + connections);

	sockeT.join('Lobby'); // Join 'Lobby' Room
	sockeT.emit('Games', games);

	// Disconnect
	sockeT.on('disconnect', function() {
		connections--;
		console.log('Client disconnected: ' + sockeT.id); // Server Message
		console.log('Connections: ' + connections);

		// End Hosted Game
		for (let i = 0; i < games.length; i++) {
			if (games[i].info.host == sockeT.id) {
				io.to(games[i].info.name).emit('Game Ended', games[i]); // Remove Players From Hosted Game
				console.log('                                               Game Deleted: ' + games[i].info.name + ' (' + games[i].info.host + ')');
				games.splice(i, 1); // Delete Game
				sockeT.broadcast.emit('Games', games); // Update Clients' Games
				clearInterval(intervals[i]); // Clear Game Interval
				intervals.splice(i, 1);
				break;
			}
		}
		// Leave Current Game
		for (let i = 0; i < games.length; i++) {
			for (let j = 0; j < games[i].players.length; j++) {
				if (games[i].players[j] == sockeT.id) { // Find current game
					sockeT.leave(games[i].info.name); // Leave 'Game' Room
					games[i].players.splice(j, 1); // Remove Player
					games[i].orgs.splice(j, 1); // Remove Player Org
					games[i].abilities.splice(j, 1); // Remove Player Abilities
					games[i].info.count = games[i].orgs.length;
					io.sockets.emit('Games', games);
					console.log('                                               Game Left: ' + games[i].info.name + ' (' + sockeT.id + ')');
					break;
				}
			}
		}
	});

	// Game Creation
	sockeT.on('Game Created', function(gamE) {
		games.push(gamE);
		io.sockets.emit('Games', games);
		sockeT.leave('Lobby'); // Leave 'Lobby' Room
		sockeT.join(gamE.info.name); // Join 'Game' Room
		console.log('                                               Game Created: ' + games[games.length - 1].info.name + ' (' + games[games.length - 1].info.host + ')');
		intervals.push(setInterval(function() { // Send updated game to all players 10 times per second
			for (let i = 0; i < games.length; i++) { // Game interval
				if (games[i].info.host == sockeT.id) {
					// games[i].info.count = games[i].players.length; // Calculate and update player count
					io.to(games[i].info.name).emit('Game', gamE); // Send updated game info to clients in game room
					break;
				}
			}
		}, 50));
	});

	// Game Joined
	sockeT.on('Game Joined', function(datA) {
		for (let i = 0; i < games.length; i++) {
			if (games[i].info.host == datA.info.host) {
				sockeT.leave('Lobby'); // Leave 'Lobby' Room
				sockeT.join(datA.info.name); // Join 'Game' Room
				games[i].players.push(sockeT.id);
				games[i].orgs.push(datA.org);
				games[i].abilities.push(datA.ability);
				games[i].info.count = games[i].orgs.length;
				io.sockets.emit('Games', games);
				for (let j = 0; j < games[i].players.length; j++) {
					if (games[i].players[j] == sockeT.id) {
						sockeT.emit('Index', { index: j, spawn: true });
						break;
					}
				}
				console.log('                                               Game Joined: ' + games[i].info.name + ' (' + sockeT.id + ')');
				break;
			}
		}
	});

	// Update Server Org
	sockeT.on('Org', function(orG) {
		for (let i = 0; i < games.length; i++) {
			if (games[i].orgs[orG.index].player == sockeT.id) {
				games[i].orgs[orG.index] = orG;
				break;
			}
		}
	});

	// Update Server Abilities
	sockeT.on('Ability', function(abilitY) {
		for (let i = 0; i < games.length; i++) {
			if (games[i].players[abilitY.index] == sockeT.id) {
				games[i].abilities[abilitY.index] = abilitY;
				break;
			}
		}
	});

	{ // Abilities
		sockeT.on('Extend', function(playeR) {
			if (playeR == sockeT.id) {
				sockeT.emit('Extend');
			} else {
				sockeT.to(playeR).emit('Extend');
			}
		});

		sockeT.on('Compress', function(playeR) {
			if (playeR == sockeT.id) {
				sockeT.emit('Compress');
			} else {
				sockeT.to(playeR).emit('Compress');
			}
		});

		// sockeT.on('Speed', function(playeR) {
		// 	if (playeR == sockeT.id) {
		// 		sockeT.emit('Speed');
		// 	} else {
		// 		sockeT.to(playeR).emit('Speed');
		// 	}
		// });

		// sockeT.on('Slow', function(playeR) {
		// 	if (playeR == sockeT.id) {
		// 		sockeT.emit('Slow');
		// 	} else {
		// 		sockeT.to(playeR).emit('Slow');
		// 	}
		// });

		sockeT.on('Immortality', function(playeR) {
			if (playeR == sockeT.id) {
				sockeT.emit('Immortality');
			} else {
				sockeT.to(playeR).emit('Immortality');
			}
		});

		sockeT.on('Stunt', function(playeR) {
			if (playeR == sockeT.id) {
				sockeT.emit('Stunt');
			} else {
				sockeT.to(playeR).emit('Stunt');
			}
		});

		sockeT.on('Stimulate', function(playeR) {
			if (playeR == sockeT.id) {
				sockeT.emit('Stimulate');
			} else {
				sockeT.to(playeR).emit('Stimulate');
			}
		});

		sockeT.on('Poison', function(playeR) {
			if (playeR == sockeT.id) {
				sockeT.emit('Poison');
			} else {
				sockeT.to(playeR).emit('Poison');
			}
		});
	}

	// Dead
	sockeT.on('Dead', function() {
		for (let i = 0; i < games.length; i++) {
			if (games[i].players.indexOf(sockeT.id) != -1) {
				for (let j = 0; j < games[i].orgs.length; j++) { // Do not use games[i].info.count server-side (orgs.length may change before count changes)
					if (games[i].orgs[j].player == sockeT.id) {
						games[i].orgs.splice(j, 1); // Remove player from game
						games[i].players.splice(j, 1);
						games[i].abilities.splice(j, 1);
						games[i].info.count = games[i].orgs.length;
						for (let k = 0; k < games[i].players.length; k++) {
							sockeT.to(games[i].players[k]).emit('Index', { index: k, spawn: false }); // Emit new indices to all players in game
						}
						break;
					}
				}
				break;
			}
		}
	});
}