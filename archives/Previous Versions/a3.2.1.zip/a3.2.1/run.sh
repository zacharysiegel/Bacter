sh ./build.sh
start http://localhost
node server.js