# Bacter
Two-Dimensional Arena Multiplayer Game

Website: [bacter.ga](http://bacter.ga)