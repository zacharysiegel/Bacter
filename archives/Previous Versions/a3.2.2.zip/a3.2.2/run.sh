sh ./src/build.sh
node ./src/app.js