# Notes

## Definitions & Notation:
    Org: (Organism) The object controlled by a player
    Member: A user is a member of a game if he is a player or a spectator
    Player: A member of a game who is currently controlling an org
    Spectator: A member of a game who is observing the game withoug controlling an org
    {Abc}: Indicates an instance of the class 'Abc'

## Abilities:
    Each player has four abilities:
        At spawn, the player chooses three abilities with two options for each.
            Each of these three abilities has an offensive and a defensive option.
            The two options for an ability are more-or-less inverses of each other.
            The pairs of abilities are listed here with the defensive option first
                Extend       --  Compress
                Immortality  --  Freeze
                Neutralize   --  Toxin
        Every player can use the fourth ability (Spore) regardless of the abilities he chooses at spawn.
    Details for each ability are listed below
        The game modes which support an ability are listed next to the ability name
#### Extend (FFA, SKM, SRV)
    Increases the organism's equilibrium radius
    Increases the number of cells in an organism
        Harder to be killed
        Increases the number of cells jettisoned by Spore
    Default key binding: x
#### Compress (FFA, SKM, SRV)
    Decreases the organism's equilibrium radius
    Decreases the number of cells in an organism
        Easier to kill a Compressed enemy
    The effect is delivered to an enemy be shooting a border cell toward the player's cursor
        'Pop' the ejected spore by reactivating the ability (re-press the key)
    Default key binding: x
#### Immmortality (FFA, SKM, SRV)
    Halts the organism's cell's natural death
        Cells may still die from secretions from spores
    Leaves trail of cells behind
        Allows for clever Spore usage
        Blocks movement of opponents through trail
    Default key binding: c
#### Freeze (FFA, SKM, SRV)
    Halts all natural processes (both birth and death) of an enemy cell
    In effect, this ability freezes the affected organism, halting all movement
    The effect is delivered to an enemy be shooting a border cell toward the player's cursor
        'Pop' the ejected spore by reactivating the ability (re-press the key)
    Default key binding: c
#### Neutralize (FFA, SKM, SRV)
    Neutralize all acid in a circular area surrounding the organism
        In reality, this would occur by secreting a base
    Immortalizes cells within the alkaline radius from acidic secretions
    The neutral area is a circle around the center of mass of the organism
        In the future, several smaller circles may be created around each cell in the organism
    Default key binding: v
#### Toxin (FFA, SKM, SRV)
    Kill all enemy cells in a circular area surrounding the organism
        In reality, this is analagous to the organism secreting an acid
    Immortalizes cells within the alkaline radius from acidic secretions
    The neutral area is a circle around the center of mass of the organism
        In the future, several smaller circles may be created around each cell in the organism
    Default key binding: v
#### Spore (FFA, SKM, SRV)
    All exposed (membranal) cells jettison from org away from the center of org
    All ejected spores secrete acid into the surrounding region
        'Pop' spores by reactivating the ability (re-press the key)
    Default key binding: [Spacebar]
#### X Stimulate (OLD):
    Accelerated Birth
    Effectively increases movement speed
#### X Poison:
    X Accelerated Death
    Decelerated Birth
    Effectively decreases movement speed
#### X Speed:
    Increase Movement Speed
#### X Slow:
    Slow Movement Speed
#### Stimulate: (CTF)
    Increases birth/death rate
    Increases movement speed
#### Tag: (CTF)
    Shoot single spore to pop on enemy
#### ? Cloak:
    Temporarily become invisible to opponents
        - Usage of abilities denied while stealthed
        - OR Usage of an ability disables cloak
#### ? Hook:
    Send line skill shot to another to opponent
    On hit, pulls opponent toward player

## Game Modes:
#### ? Freeze Tag (FZT)
    Use freeze ability only
    Freezes org indefinately until:
        ? Teammate makes contact
        ? Teammate tags with tag ability
           Could be same ability key as freeze or second tag ability
#### ? Territories (TRT)
    Players are assigned a small circular territory at spawn
            
## Skins:
    ? Amoeba
        Mark points on each border cell and connect with a smooth curve
        If cell stands alone, draw circle
        May have to introduce additional noise into the curve so it looks more natural/random
        Significant enough to be behind a pay-wall
      
## To-Do:
#### a3.2.3 - Organization
    ✓ Improve documentation
        ✓ README.md
        ✓ New license
        ✓ Gameplay Guide
        ✓ Usage Guide
    ✓ Add timeout for 'Permission Denied' and 'Permission Granted' to be closed regardless of server response to 'Check Permission'
    ✓ Improve build and start scripts (rename run.sh to start.sh)
    ✓ Encapsulate z.js into class Z
        ✓ Update occurances of z.js functions to Z.[function()]
    ✓ Update React lifecycle functions
    ✓ Add '4th Ability' row to Join Game Options menu with Spore checkbox always checked
    ✓ Encapsulate game.js into class Game
        ✓ static game variable (game -> Game.game)
    ✓ Encapsulate permission stuff into Permissions class
    ✓ Encapsulate server-side game info into Games class
    ✓ Encapsulate socket.io emit listeners into SocketListener class
    ✓ Encapsulate cell.js into class Cell
    ✓ Encapsulate flag.js into class Flag
    ✓ Cell.equals comparison with tolerance
    ✓ Compartmentalize server into modules
    ✓ Optimize Org.getRegionInfo
        ✓ Convert all regions to sets (no order + no duplication)
    ✓ On mouse over list inputs, change pointer to click
    ✓ On mouse over radio inputs, change pointer to click
    ✓ Add projects and issues to GitHub page
    ✓ Clean up code
        ✓ Rename game.info.count to game.info.player_count
        ✓ Compartmentalize config.js
        ✓ Encapsulate messages.js into class Messages
        ✓ Encapsulate org.js into class Org
        ✓ Convert Games class (server-side) to array of Game class instances
        ✓ Convert data parameters to declarative parameters
    ✓ Add Terminate fullscreen task once f11 is pressed
    ✓ Add 'Damage the bot to progress' for Toxin tutorial
    ✓ Convert 'world type' to 'world shape'
    ✓ Create BoardEntry class
    ✓ Fix no break out of submit menu switch
    ✓ Fix occasional client doesn't receive 'Games' interval emission
    ✓ Fix frequent client reconnection
    ✓ Fix org update on title screen
    ✓ Fix unnecessary 'check permission' emit before issue(issue) is invoked
    ✓ Fix flag socket reception bug
    ✓ Fix 'There is an issue with skin selection' in spectate join menu
    ✓ Fix white title background after forced exit of game
    ✓ Fix Abilities are ineffectual against tutorial bots
    ✓ Fix text alignment in menu list
    ✓ Fix org world border collision
    ✓ Fix unnecessary socket communication in tutorial
    ✓ Fix shrink interval not cleared at end of round
    ✓ Fix world size should reset at start of waiting period, not end of round
    ✓ Fix no border margin in natural_death
    ✓ Fix server crash on concurrent deletion of a game utilizing rounds
    ✓ Fix player doesn't stay in spectators list after end of round
    ✓ Fix player leaves during round delay
    ✓ Fix force spawn while at respawn menu
    ✓ Fix force spawn while at pause-spectate menu
    ✓ FIX player not readded to leaderboard after respawning in start round delay
    ✓ FIX game is closed when try to enter game
        ✓ games is empty array
        ✓ grantedJoin is not called
        ✓ org.cell is recursively defined -- causes problems when sent through socketio
        ✓ socket.on('Create Game') not called when Game.createGame is called
        ✓ socket.emit (client) doesnt work inside setInterval
    ✓ FIX screen is white when entering game
    ✓ FIX title screen org life
    ✓ FIX incorrect movement
    ✓ FIX cpu/ram strain on title screen after few seconds
    ✓ FIX ability timers are black circle in tutorial
    ✓ FIX Pause game menu resets color and skin values
    ✓ FIX freeze on second user's connection
    ✓ FIX cannot activate abilities
    ✓ FIX Game.game is not updated when player disconnects
    ✓ FIX Game.game not updated when player leaves game without disconnect
    ✓ FIX Game not found error Games.js:28
    ✓ FIX Orgs overlap
    ✓ FIX Doesn't kick other players out of game when host disconnects
    ✓ FIX Tutorial white ghost
    ✓ FIX spore-secrete doesnt stop birth
    ✓ FIX 'Game Closed' when host joins (Presumed to be fixed, not sure because don't know how to replicate the bug)
    ✓ FIX leave game but still emit 'board'
    ✓ FIX resize flicker
    ✓ FIX multiple intervals after creating and deleting multiple games
    ✓ FIX placeholders missing when menu structure changes
    ✓ FIX footer shifted over in browser
    ✓ FIX listen_ability Game not found upon leaving game
    ✓ FIX spawn outside world
#### a3.2.4 - Optimization
    Data Structures
        Store games in map where host socket.id is key
        Convert 'games' array into hash map
        Convert 'securities' array into hash map
        Convert 'game.players' array into hash map
        Convert 'game.spectators' array into hash map
        Convert 'org.cells' array to a Set
            Learn about Sets
    Create a Board entry class
    Compartmentalize submit.js
    Add field game.info.user_count
    Add field game.info.spectator_count
        Getter with user - player subtraction
    In each cell in an organism, store a pointer to the 4/8 surrounding cells
        Convert org.cells to a map
    Write a removePlayer function within game
        Code consistency and reuse and easier debugging
        Call in listen_leave_game
    Write a removeSpectator function within game
        Code consistency and reuse and easier debugging
        Call in listen_leave_game
    Optimize Org.birth
    Optimize Org.naturalDeath
        Store in each cell a number corresponding to its index in its org's cells array
            This allows for O(1) cell lookup in org's cells array
            Currently O(n)
            Optimizes more than just Org.naturalDeath, so for loops can be removed across project
            A map can also be used (normal JS object)
                Each cell must have a unique string identifier to use as a key
                    key: `x,y` , value: {Cell}
                    The above format allows each cell to easily point to the surrounding cells without knowing if they exist
    Optimize Org.renderAll
        Start from exposed cell and render a rectangle across until reaching another exposed cell
    Create a maximum distance away from world border which a spectator can move
    Skip fullscreen task once F11 is pressed
    Add scrolling in menus
        React may have something nice
        Think about how resizing the window affects scrolling
    Convert 'Game Mode' <select> to a Radio element
    Create easily-editable visual configurations
        e.g. world border weight/color
    Convert 'game has ended' alert to a Message on the title screen
    Convert 'max player capacity' alert to a Message (don't render menu)
    Fix cannot respawn after dying in tutorial
    Fix game doesn't appear in browser if all players are dead
    Fix browser button inconsistent row background
    Fix crash when player kills himself with shoot
    Fix press enter in color picker joins game
    Fix name labels do not show while spectating
    Fix listen_org player not found in game 'bug'
        When spectator is force-respawned, 'org' event is emitted before server's {Game} is updated
    Fix create game submit button runs submit twice
    Fix round timers when host is not clicked-in
#### a3.3.0 - Capture the Flag
    Fix ctf base world corner rendering bug
    CTF
        ✓ Round system
            Round end at 3 captures
        ✓ No friendly fire
        ✓ Tag
        ✓ Larger minimum world
        ✓ Random spawn
        ✓ Color team bases
        Flag placement
        Base collision detection
#### a3.4.0 - Infection
    INF
        Round system
            Randomize teams each round
        ✓ No friendly fire
        ✓ Tag
        Boost ability
#### a3.5.0 - King of the Hill
    KTH
        Round system
        Score counting
            Based upon time spent controlling the point
        Hill placement
        Integrate teams api
#### aX.X.X
    Obfuscate client-side code to prevent easy hacking
    Flow -- Static type checker for JavaScript
        npm install --save-dev flow-bin
        npm install --save-dev @babel/preset-flow
    OR TypeScript -- Compiled JavaScript
        npm install --save-dev typescript
        npx tsc --init
    Enumify -- Enums for JavaScript
        Enum for Game.state
        Enum for Game.game.rounds.waiting/delayed/...
    RethinkDB -- Realtime database
    Cross Browser Testing
        crossbrowsertesting.com
    Reduce trust updating server versions of objects (org, board, ability, etc.)
        org:
            Check if coefficient is one of 3 enumerated values
            Check if size is within reasonable bounds
                bounds may be different if immortality is on
        board:
            Kills and deaths should only ever change in increments of 1
    Gather end-of-game scoring data to analyze for balancing
    Encrypt passwords when sending to server
        Client encrypts password, sends to server
        Server encrypts encrypted password, sends to client
        Client decrypts doubly-encrypted password, sends to server
        Server decrypts encrypted password, stores value as hash (bCrypt)
    Tutorial should be functional without the server
        Not that that function is desired, but the server should not have do waste computation time on the tutorial
    Add controls settings menu
        Ability keys
        Respawn key
        Pause key
        Pass in callback function for the menu to call when clicking 'back' or 'submit'
    Small square skin
        In effect, it is an inverted ghost skin
    Sparks skin
        On birth, release sparks particle effect
    ? Player minimum browser column
    Players / Player Maximum column
    Fullscreen button
    Mouse click, in, and out behavior correction
        Do not change background color on mouse down, only on mouse hover
    More applicable freeze tooltip art
    Add substance to the world (background)
        Pickups that lower cooldowns
        Pickups that increase radius
    Spores decelerate over time (Friction)
        Constant acceleration - Integrate
    When spores die, shrink radius
        Delete spore when radius is less than one pixel
    When secretions end, shrink radius
        Delete when radius is less than one pixel
    Use images for tooltip art
        Less computation (constant time reduction)
        Higher detail/resolution
    Move cell death to be computed on the server
        More fair, otherwise player could switch tabs when about to die
    Add info menu
    Add popup info box
    Custom select menu
    Customize menu alerts
    Customize death alert
    Customize game ended alert
    Transparent pause menu
    Add music
    Add SFX
    ? Centralize hit detections and such at host
    Graphical overhaul
        World border
            If substance, can remove
        World substance
        Spore animations
        Secrete animations
            Inner circle expands through interval
        X Animation over selected abilities in chooseAbilities()
        Graphics settings/Performance levels
