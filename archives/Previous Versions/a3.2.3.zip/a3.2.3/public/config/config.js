const config = {
    colors: {},
    game: {},
    menus: {},
    settings: {}
};
