var menus = {
	width: 900, 
	top: 0, 
	padding: 0, 
	color: { r: 240, g: 240, b: 240 }, 
	header: {
		padding: 9, 
		height: 32, 
		backgroundColor: { r: 0, g: 0, b: 0 }, 
		color: { r: 255, g: 255, b: 255 }, 
		font: 'Verdana', 
		size: 16,
		weight: 'bold'
	}, 
	rows: {
		height: 21, 
		color: { r: 255, g: 255, b: 255 }, 
		margin: 0, 
		padding: 0
	}, 
	cells: {
		count: 2, 
		margin: 0, 
		padding: 5, 
		border: {
			color: { r: 0, g: 0, b: 0 }, 
			width: 0, 
			style: 'solid'
		}
	}, 
	text: {
		color: { r: 0, g: 0, b: 0 }, 
		font: 'Georgia, serif', 
		size: 15
	}, 
	inputs: {
		color: { r: 0, g: 0, b: 0 }, 
		backgroundColor: { r: 230, g: 230, b: 230 }, 
		border: {
			color: { r: 50, g: 50, b: 50 }, 
			width: 2, 
			radius: 3, 
			style: 'solid'
		}, 
		width: 100, 
		height: 26, 
		font: 'serif', 
		size: 14
	}, 
	radios: {
		width: 16, 
		height: 18, 
		backgroundColor: { r: 255, g: 255, b: 255 }, 
		selectColor: { r: 190, g: 190, b: 190 }
	}, 
	border: {
		color: { r: 0, g: 0, b: 0 }, 
		width: 0, 
		style: 'solid'
	}, 
	button: {
		width: 95, 
		height: 33, 
		backgroundColor: { r: 240, g: 240, b: 240 }, 
		color: { r: 0, g: 0, b: 0 }, 
		font: 'Gerogia, serif', 
		size: 16, 
		weight: 'bold', 
		top: 20, 
		borderRadius: 2, 
	}, 
	footer: {
		backgroundColor: { r: 0, g: 0, b: 0 }, 
		color: { r: 255, g: 255, b: 255 }, 
		height: 30, 
		font: 'Verdana', 
		size: 15
	}, 
	create: {
		header: {
			text: 'Game Creation Options'
		}, 
		button: {
			text: 'Create'
		}, 
		options: [ 'Game Title', 'Password', 'World Type', 'World Width', 'World Height', 'Player Cap', 'Leaderboard Length', 'Game Mode' ], // Team count not included because ffa is default
		values:  [ 'text',        'text',    'list',       'number',      'number',       'number',     'number',             'list'      ], 
		units:   [ undefined, undefined, 'px', 'px'], 
		editNums: function() {
			{ // World Width and Height
				let widthInput = document.getElementById('World Width Input');
				let heightInput = document.getElementById('World Height Input');
				if (widthInput != null && heightInput != null) { // Prevents listener stacking
					widthInput.placeholder = _worldwidth;
					heightInput.placeholder = _worldheight;
					let modeInput = document.getElementById('Game Mode Input');
					if (modeInput.value == 'ctf') {
						widthInput.min = 700;
						heightInput.min = 700;
					} else {
						widthInput.min = 300;
						heightInput.min = 300;
					}
					widthInput.max = 100000;
					heightInput.max = 100000;
					let wmin = parseFloat(widthInput.min);
					let wmax = parseFloat(widthInput.max);
					let hmin = parseFloat(heightInput.min);
					let hmax = parseFloat(heightInput.max);
					widthInput.addEventListener('change', function() {
						if (parseFloat(widthInput.value) < wmin) {
							widthInput.value = wmin;
						} else if (parseFloat(widthInput.value) > wmax) {
							widthInput.value = wmax;
						}
						if (parseFloat(widthInput.value) != parseFloat(heightInput.value)) {
							heightInput.value = parseFloat(widthInput.value);
						}
					});
					heightInput.addEventListener('change', function() {
						if (parseFloat(heightInput.value) < hmin) {
							heightInput.value = hmin;
						} else if (parseFloat(heightInput.value) > hmax) {
							heightInput.value = hmax;
						}
						if (parseFloat(widthInput.value) != parseFloat(heightInput.value)) {
							widthInput.value = parseFloat(heightInput.value);
						}
					});
				}
			}
			{ // Player Cap
				let pcInput = document.getElementById('Player Cap Input');
				if (pcInput != null) { // Prevents listener stacking
					pcInput.placeholder = _playercap;
					pcInput.min = 2;
					pcInput.addEventListener('change', function() {
						if (parseFloat(pcInput.value) < parseFloat(pcInput.min)) {
							pcInput.value = parseFloat(pcInput.min);
						}
					});
				}
			}
			{ // Player Minimum
				let pmInput = document.getElementById('Player Minimum Input');
				if (pmInput != null) {
					pmInput.placeholder = _playermin;
					pmInput.min = 2;
					pmInput.addEventListener('change', function() {
						if (pmInput != null) {
							if (parseFloat(pmInput.value) < parseFloat(pmInput.min)) {
								pmInput.value = parseFloat(pmInput.min);
							}
							let tcInput = document.getElementById('Team Count Input');
							if (tcInput != null) {
								if (parseFloat(tcInput.value) > parseFloat(pmInput.value) || pmInput.value == '') {
									pmInput.value = parseFloat(tcInput.value);
								}
							}
						}
					});
				}
			}
			{ // Leaderboard Length
				let boardLengthInput = document.getElementById('Leaderboard Length Input');
				if (boardLengthInput != null) {
					boardLengthInput.placeholder = _boardlength;
					boardLengthInput.min = 1;
					boardLengthInput.max = 20;
					boardLengthInput.addEventListener('change', function() {
						if (boardLengthInput != null) {
							if (parseFloat(boardLengthInput.value) < parseFloat(boardLengthInput.min)) {
								boardLengthInput.value = parseFloat(boardLengthInput.min);
							} else if (parseFloat(boardLengthInput.value) > parseFloat(boardLengthInput.max)) {
								boardLengthInput.value = parseFloat(boardLengthInput.max);
							}
							if (parseFloat(boardLengthInput.value) % 1 != 0) { // If length is not an integer
								boardLengthInput.value = floor(parseFloat(boardLengthInput.value));
							}
						}
					});
				}
			}
			{ // Team Count
				let tcInput = document.getElementById('Team Count Input');
				if (tcInput != null) {
					tcInput.placeholder = _teamcount;
					tcInput.min = 2;
					tcInput.max = teamColors.length; // = 4
					tcInput.addEventListener('change', function() {
						if (tcInput != null) {
							if (parseFloat(tcInput.value) < parseFloat(tcInput.min)) {
								tcInput.value = parseFloat(tcInput.min);
							} else if (parseFloat(tcInput.value) > parseFloat(tcInput.max)) {
								tcInput.value = parseFloat(tcInput.max);
							}
							if (parseFloat(tcInput.value) % 1 != 0) { // If length is not an integer
								tcInput.value = floor(parseFloat(tcInput.value));
							}
							let pmInput = document.getElementById('Player Minimum Input');
							if (pmInput != null) {
								if (parseFloat(tcInput.value) > parseFloat(pmInput.value) || pmInput.value == '') {
									pmInput.value = parseFloat(tcInput.value);
								}
							}
						}
					});
				}
			}
		}, 
		editLists: function() {
			{ // World Type
				let wtInput = document.getElementById('World Type Input');
				if (wtInput != null) { // Prevents listener stacking
					let rectOption = document.createElement('option');
					wtInput.appendChild(rectOption);
					rectOption.value = 'Rectangle';
					rectOption.selected = 'selected';
					rectOption.innerHTML = 'Square';
					let ellipseOption = document.createElement('option');
					wtInput.appendChild(ellipseOption);
					ellipseOption.value = 'Ellipse';
					ellipseOption.innerHTML = 'Circle';
				}
			}
			// { // World Color
			// 	let worldColorInput = document.getElementById('World Color Input');
			// 	let blackOption = document.createElement('option');
			// 	worldColorInput.appendChild(blackOption);
			// 	blackOption.value = 'Black';
			// 	blackOption.selected = 'selected';
			// 	blackOption.style.backgroundColor = 'rgb(0, 0, 0)';
			// 	blackOption.style.color = 'rgb(255, 255, 255)';
			// 	blackOption.innerHTML = 'Black';
			// 	let whiteOption = document.createElement('option');
			// 	worldColorInput.appendChild(whiteOption);
			// 	whiteOption.value = 'White';
			// 	whiteOption.style.backgroundColor = 'rgb(255, 255, 255)';
			// 	whiteOption.style.color = 'rgb(0, 0, 0)';
			// 	whiteOption.innerHTML = 'White';
			// }
			{ // Game Mode
				let modeInput = document.getElementById('Game Mode Input');
				if (modeInput != null) { // Prevents listener stacking
					let ffaOption = document.createElement('option');
					ffaOption.value = 'ffa';
					ffaOption.selected = 'selected';
					ffaOption.innerHTML = 'Free for All';
					modeInput.appendChild(ffaOption);
					let skmOption = document.createElement('option');
					skmOption.value = 'skm';
					skmOption.innerHTML = 'Skirmish';
					modeInput.appendChild(skmOption);
					let srvOption = document.createElement('option');
					srvOption.value = 'srv';
					srvOption.innerHTML = 'Survival';
					modeInput.appendChild(srvOption);
					let ctfOption = document.createElement('option');
					ctfOption.value = 'ctf';
					ctfOption.innerHTML = 'Capture the Flag';
					ctfOption.disabled = 'disabled';
					modeInput.appendChild(ctfOption);
					let infOption = document.createElement('option');
					infOption.value = 'inf';
					infOption.innerHTML = 'Infection';
					infOption.disabled = 'disabled';
					modeInput.appendChild(infOption);
					let kthOption = document.createElement('option');
					kthOption.value = 'kth';
					kthOption.innerHTML = 'King of the Hill';
					kthOption.disabled = 'disabled';
					modeInput.appendChild(kthOption);
					modeInput.addEventListener('change', function() {
						// Leaderboard Length & Team Count
						if (modeInput.value == 'ctf') { // Set world width and height
							let widthInput = document.getElementById('World Width Input');
							let heightInput = document.getElementById('World Height Input');
							let width = parseFloat(widthInput.value);
							let height = parseFloat(widthInput.value);
							let wmin = 700;
							let hmin = 700;
							if (width < wmin || height < hmin) {
								widthInput.value = wmin;
								heightInput.value = hmin;
							}
						}
						if (modeInput.value == 'skm' || modeInput.value == 'ctf') { // If team game
							if (document.getElementById('Leaderboard Length Input') != null) { // If leaderboard length input is present
								let row = document.getElementById('Leaderboard Length Input').parentNode.parentNode;
								row.parentNode.removeChild(row); // Remove Leaderboard Length option
								let rows = document.getElementById('Menu Body').children; // Reset Row Coloration
								for (let i = 0; i < rows.length; i++) {
									let row = rows[i];
									row.style.backgroundColor = 'rgb(' + menus.rows.color.r + ', ' + menus.rows.color.g + ', ' + menus.rows.color.b + ')';
									if (i % 2 == 0) {
										row.style.backgroundColor = 'rgb(' + (menus.rows.color.r - 15) + ', ' + (menus.rows.color.g - 15) + ', ' + (menus.rows.color.b - 15) + ')';
									}
								}
							}
							if (document.getElementById('Team Count Input') == null) { // If team count input not present
								let modeInput = document.getElementById('Game Mode Input'); // Create Team Count Option
								let modeCell = modeInput.parentNode;
								let modeRow = modeCell.parentNode;
								let tableBody = modeRow.parentNode;
								let row = document.createElement('tr');
								tableBody.insertBefore(row, modeRow);
								left = document.createElement('td');
								row.appendChild(left);
								left.style.margin = menus.cells.margin + 'px';
								left.style.padding = menus.cells.padding + 'px';
								left.style.width = menus.width / 2 + 'px';
								left.style.borderColor = 'rgb(' + menus.cells.border.color.r + ', ' + menus.cells.border.color.g + ', ' + menus.cells.border.color.b + ')';
								left.style.borderWidth = menus.cells.border.width + 'px';
								left.style.borderStyle = menus.cells.border.style;
								left.style.textAlign = 'right';
								left.innerHTML = 'Team Count';
								right = document.createElement('td');
								row.appendChild(right);
								right.style.borderColor = 'rgb(' + menus.cells.border.color.r + ', ' + menus.cells.border.color.g + ', ' + menus.cells.border.color.b + ')';
								right.style.borderWidth = menus.cells.border.width + 'px';
								right.style.borderStyle = menus.cells.border.style;
								tcInput = document.createElement('input');
								right.appendChild(tcInput);
								tcInput.id =  'Team Count Input';
								tcInput.style.width = menus.inputs.width + 'px';
								tcInput.style.height = menus.inputs.height + 'px';
								tcInput.type = 'number';
								tcInput.value = '';
								tcInput.style.autocomplete = 'on';
								tcInput.style.boxSizing = 'border-box';
								tcInput.style.textAlign = 'center';
								tcInput.style.fontFamily = menus.inputs.font;
								tcInput.style.fontSize = menus.inputs.size + 'px';
								tcInput.style.outline = 'none';
								tcInput.style.backgroundColor = 'rgb(255, 255, 255)';
								tcInput.style.borderWidth = '0px';
								tcInput.style.borderBottomColor = 'rgb(' + menus.inputs.border.color.r + ', ' + menus.inputs.border.color.g + ', ' + menus.inputs.border.color.b + ')';
								tcInput.style.borderBottomWidth = menus.inputs.border.width + 'px';
								tcInput.style.borderRadius = menus.inputs.border.radius + 'px';
								tcInput.addEventListener('focus', function() {
									tcInput.style.backgroundColor = 'rgb(' + menus.inputs.backgroundColor.r + ', ' + menus.inputs.backgroundColor.g + ', ' + menus.inputs.backgroundColor.b + ')';
								});
								tcInput.addEventListener('focusout', function() {
									tcInput.style.backgroundColor = 'rgb(255, 255, 255)';
								});
								menus.create.editNums();
								let rows = document.getElementById('Menu Body').children; // Reset Row Coloration
								for (let i = 0; i < rows.length; i++) {
									let row = rows[i];
									row.style.backgroundColor = 'rgb(' + menus.rows.color.r + ', ' + menus.rows.color.g + ', ' + menus.rows.color.b + ')';
									if (i % 2 == 0) {
										row.style.backgroundColor = 'rgb(' + (menus.rows.color.r - 15) + ', ' + (menus.rows.color.g - 15) + ', ' + (menus.rows.color.b - 15) + ')';
									}
								}
							}
						} else { // If not a team game
							if (document.getElementById('Leaderboard Length Input') == null) { // If leaderboard length input is not present
								let modeCell = modeInput.parentNode; // Create Leaderboard Length Option
								let modeRow = modeCell.parentNode;
								let tableBody = modeRow.parentNode;
								let row = document.createElement('tr');
								tableBody.insertBefore(row, modeRow);
								left = document.createElement('td');
								row.appendChild(left);
								left.style.margin = menus.cells.margin + 'px';
								left.style.padding = menus.cells.padding + 'px';
								left.style.width = menus.width / 2 + 'px';
								left.style.borderColor = 'rgb(' + menus.cells.border.color.r + ', ' + menus.cells.border.color.g + ', ' + menus.cells.border.color.b + ')';
								left.style.borderWidth = menus.cells.border.width + 'px';
								left.style.borderStyle = menus.cells.border.style;
								left.style.textAlign = 'right';
								left.innerHTML = 'Leaderboard Length';
								right = document.createElement('td');
								row.appendChild(right);
								right.style.borderColor = 'rgb(' + menus.cells.border.color.r + ', ' + menus.cells.border.color.g + ', ' + menus.cells.border.color.b + ')';
								right.style.borderWidth = menus.cells.border.width + 'px';
								right.style.borderStyle = menus.cells.border.style;
								lengthInput = document.createElement('input');
								right.appendChild(lengthInput);
								lengthInput.id =  'Leaderboard Length Input';
								lengthInput.style.width = menus.inputs.width + 'px';
								lengthInput.style.height = menus.inputs.height + 'px';
								lengthInput.type = 'number';
								lengthInput.value = '';
								lengthInput.style.autocomplete = 'on';
								lengthInput.style.boxSizing = 'border-box';
								lengthInput.style.textAlign = 'center';
								lengthInput.style.fontFamily = menus.inputs.font;
								lengthInput.style.fontSize = menus.inputs.size + 'px';
								lengthInput.style.outline = 'none';
								lengthInput.style.backgroundColor = 'rgb(255, 255, 255)';
								lengthInput.style.borderWidth = '0px';
								lengthInput.style.borderBottomColor = 'rgb(' + menus.inputs.border.color.r + ', ' + menus.inputs.border.color.g + ', ' + menus.inputs.border.color.b + ')';
								lengthInput.style.borderBottomWidth = menus.inputs.border.width + 'px';
								lengthInput.style.borderRadius = menus.inputs.border.radius + 'px';
								lengthInput.addEventListener('focus', function() {
									lengthInput.style.backgroundColor = 'rgb(' + menus.inputs.backgroundColor.r + ', ' + menus.inputs.backgroundColor.g + ', ' + menus.inputs.backgroundColor.b + ')';
								});
								lengthInput.addEventListener('focusout', function() {
									lengthInput.style.backgroundColor = 'rgb(255, 255, 255)';
								});
								menus.create.editNums();
								let rows = document.getElementById('Menu Body').children; // Reset Row Coloration
								for (let i = 0; i < rows.length; i++) {
									let row = rows[i];
									row.style.backgroundColor = 'rgb(' + menus.rows.color.r + ', ' + menus.rows.color.g + ', ' + menus.rows.color.b + ')';
									if (i % 2 == 0) {
										row.style.backgroundColor = 'rgb(' + (menus.rows.color.r - 15) + ', ' + (menus.rows.color.g - 15) + ', ' + (menus.rows.color.b - 15) + ')';
									}
								}
							}
							if (document.getElementById('Team Count Input') != null) { // If team count input is not present
								let tcInput = document.getElementById('Team Count Input'); // Remove Team Count Option
								let cell = tcInput.parentNode;
								let row = cell.parentNode;
								row.parentNode.removeChild(row);
								let rows = document.getElementById('Menu Body').children; // Reset Row Coloration
								for (let i = 0; i < rows.length; i++) {
									let row = rows[i];
									row.style.backgroundColor = 'rgb(' + menus.rows.color.r + ', ' + menus.rows.color.g + ', ' + menus.rows.color.b + ')';
									if (i % 2 == 0) {
										row.style.backgroundColor = 'rgb(' + (menus.rows.color.r - 15) + ', ' + (menus.rows.color.g - 15) + ', ' + (menus.rows.color.b - 15) + ')';
									}
								}
							}
						}
						// Player Minimum
						let pmInput = document.getElementById('Player Minimum Input'); 
						if (modeInput.value == 'ffa' || modeInput.value == 'skm') {
							if (pmInput != null) { // If player minimum option is present
								let cell = pmInput.parentNode; // Remove player minimum option
								let row = cell.parentNode;
								row.parentNode.removeChild(row);
								let rows = document.getElementById('Menu Body').children; // Reset Row Coloration
								for (let i = 0; i < rows.length; i++) {
									let row = rows[i];
									row.style.backgroundColor = 'rgb(' + menus.rows.color.r + ', ' + menus.rows.color.g + ', ' + menus.rows.color.b + ')';
									if (i % 2 == 0) {
										row.style.backgroundColor = 'rgb(' + (menus.rows.color.r - 15) + ', ' + (menus.rows.color.g - 15) + ', ' + (menus.rows.color.b - 15) + ')';
									}
								}
							}
						} else if (modeInput.value == 'srv' || modeInput.value == 'ctf' || modeInput.value == 'inf' || modeInput.value == 'kth') {
							if (pmInput == null) { // If player minimum option is not present
								let capInput = document.getElementById('Player Cap Input'); // Add player minimum option
								let capCell = capInput.parentNode;
								let capRow = capCell.parentNode;
								let tableBody = capRow.parentNode;
								let row = document.createElement('tr');
								tableBody.insertBefore(row, capRow);
								left = document.createElement('td');
								row.appendChild(left);
								left.style.margin = menus.cells.margin + 'px';
								left.style.padding = menus.cells.padding + 'px';
								left.style.width = menus.width / 2 + 'px';
								left.style.borderColor = 'rgb(' + menus.cells.border.color.r + ', ' + menus.cells.border.color.g + ', ' + menus.cells.border.color.b + ')';
								left.style.borderWidth = menus.cells.border.width + 'px';
								left.style.borderStyle = menus.cells.border.style;
								left.style.textAlign = 'right';
								left.innerHTML = 'Player Minimum';
								right = document.createElement('td');
								row.appendChild(right);
								right.style.borderColor = 'rgb(' + menus.cells.border.color.r + ', ' + menus.cells.border.color.g + ', ' + menus.cells.border.color.b + ')';
								right.style.borderWidth = menus.cells.border.width + 'px';
								right.style.borderStyle = menus.cells.border.style;
								pmInput = document.createElement('input');
								right.appendChild(pmInput);
								pmInput.id =  'Player Minimum Input';
								pmInput.style.width = menus.inputs.width + 'px';
								pmInput.style.height = menus.inputs.height + 'px';
								pmInput.type = 'number';
								pmInput.value = '';
								pmInput.style.autocomplete = 'on';
								pmInput.style.boxSizing = 'border-box';
								pmInput.style.textAlign = 'center';
								pmInput.style.fontFamily = menus.inputs.font;
								pmInput.style.fontSize = menus.inputs.size + 'px';
								pmInput.style.outline = 'none';
								pmInput.style.backgroundColor = 'rgb(255, 255, 255)';
								pmInput.style.borderWidth = '0px';
								pmInput.style.borderBottomColor = 'rgb(' + menus.inputs.border.color.r + ', ' + menus.inputs.border.color.g + ', ' + menus.inputs.border.color.b + ')';
								pmInput.style.borderBottomWidth = menus.inputs.border.width + 'px';
								pmInput.style.borderRadius = menus.inputs.border.radius + 'px';
								pmInput.addEventListener('focus', function() {
									pmInput.style.backgroundColor = 'rgb(' + menus.inputs.backgroundColor.r + ', ' + menus.inputs.backgroundColor.g + ', ' + menus.inputs.backgroundColor.b + ')';
								});
								pmInput.addEventListener('focusout', function() {
									pmInput.style.backgroundColor = 'rgb(255, 255, 255)';
								});
								menus.create.editNums();
								let rows = document.getElementById('Menu Body').children; // Reset Row Coloration
								for (let i = 0; i < rows.length; i++) {
									let row = rows[i];
									row.style.backgroundColor = 'rgb(' + menus.rows.color.r + ', ' + menus.rows.color.g + ', ' + menus.rows.color.b + ')';
									if (i % 2 == 0) {
										row.style.backgroundColor = 'rgb(' + (menus.rows.color.r - 15) + ', ' + (menus.rows.color.g - 15) + ', ' + (menus.rows.color.b - 15) + ')';
									}
								}
							}
						}
					});
				}
			}
		}, 
		submit: function() {
			var ok = true; // Check for inputs' validities
			{ // Game Title
				var title = document.getElementById('Game Title Input').value;
				if (title == '' || title == undefined || title == null) { // If empty
					ok = false;
					alert('Title cannot be left blank');
				} else {
					for (let i = 0; i < games.length; i++) {
						if (title == games[i].info.title) { // Find matching title to another game
							ok = false;
							alert('Title matches that of another game');
							break;
						}
					}
				}
			}
			{ // World Width and Height
				let widthInput = document.getElementById('World Width Input');
				var width = parseFloat(widthInput.value);
				if (width == '' || width == undefined || width == null || width !== width) { // width !== width tests for NaN
					width = parseFloat(widthInput.placeholder);
				}
				let heightInput = document.getElementById('World Height Input');
				var height = parseFloat(heightInput.value);
				if (height == '' || height == undefined || height == null || height !== height) {
					height = parseFloat(heightInput.placeholder);
				}
				if (width < parseFloat(widthInput.min) || height < parseFloat(heightInput.min)) {
					ok = false;
					alert('Dimensions must be at least ' + widthInput.min + ' x ' + heightInput.min + ' px');
				} else if (width > parseFloat(widthInput.max) || height > parseFloat(heightInput.max)) {
					ok = false;
					alert('Dimensions can be at most ' + widthInput.max + ' x ' + heightInput.max + ' px');
				}
				if (width != height) {
					ok = false;
					alert('Width and height must be equivalent');
				}
			}
			{ // Player Cap
				let playerCapInput = document.getElementById('Player Cap Input');
				var cap = parseFloat(playerCapInput.value);
				let pmInput = document.getElementById('Player Minimum Input');
				if (cap == '' || cap == undefined || cap == null || cap !== cap) {
					cap = playerCapInput.placeholder;
				} else if (cap < parseFloat(playerCapInput.min)) {
					ok = false;
					alert('Player cap must be at least ' + parseFloat(playerCapInput.min));
				} else if (cap % 1 != 0) {
					ok = false;
					alert('Player cap must be a whole number');
				} else if (cap < parseFloat(pmInput.value)) {
					ok = false;
					alert('Player cap cannot be less than player minimum');
				}
			}
			{ // Player Minimum
				let pmInput = document.getElementById('Player Minimum Input');
				if (pmInput != null) {
					var minimum = parseFloat(pmInput.value);
					if (minimum == '' || minimum == undefined || minimum == null || minimum !== minimum) {
						minimum = parseFloat(pmInput.placeholder);
					} else if (minimum < parseFloat(pmInput.min)) {
						ok = false;
						alert('Player minimum must be at least ' + parseFloat(pmInput.min));
					} else if (minimum % 1 != 0) {
						ok = false;
						alert('Player minimum must be a whole number');
					}
				}
			}
			{ // Leaderboard Length
				let boardLengthInput = document.getElementById('Leaderboard Length Input');
				if (boardLengthInput != null) {
					var show = parseFloat(boardLengthInput.value);
					if (show == '' || show == undefined || show == null || show !== show) {
						show = parseFloat(boardLengthInput.placeholder);
					} else if (show < parseFloat(boardLengthInput.min)) {
						ok = false;
						alert('Leaderboard length must be at least ' + parseFloat(boardLengthInput.min));
					} else if (show > parseFloat(boardLengthInput.max)) {
						ok = false;
						alert('Leaderboard length can be at most ' + parseFloat(boardLengthInput.max));
					} else if (show % 1 != 0) {
						ok = false;
						alert('Leaderboard length must be a whole number');
					}
				}
			}
			{ // Team Count
				let tcInput = document.getElementById('Team Count Input');
				if (tcInput != null) {
					var teamCount = parseFloat(tcInput.value);
					let pmInput = document.getElementById('Player Minimum Input');
					if (teamCount == '' || teamCount == undefined || teamCount == null || teamCount !== teamCount) {
						teamCount = parseFloat(tcInput.placeholder);
					} else if (teamCount < parseFloat(tcInput.min)) {
						ok = false;
						alert('Team count must be at least ' + parseFloat(tcInput.min));
					} else if (teamCount > parseFloat(tcInput.max)) {
						ok = false;
						alert('Team count can be at most ' + parseFloat(tcInput.max));
					} else if (teamCount % 1 != 0) {
						ok = false;
						alert('Team count must be a whole number');
					} else if (teamCount > parseFloat(pmInput.value)) {
						ok = false;
						alert('Player minimum cannot be less than the number of teams');
					}
				}
			}
			if (ok == true) {
				let password = document.getElementById('Password Input').value;
				let type = document.getElementById('World Type Input').value.toLowerCase();
				let color = 'black'; // document.getElementById('World Color Input').value.toLowerCase(); // Only black world is enabled
				let mode = document.getElementById('Game Mode Input').value;
				createGame({
					title: title, 
					password: password, 
					type: type, 
					width: width, 
					height: height, 
					color: color, 
					cap: cap, 
					show: show, 
					mode: mode, 
					teamCount: teamCount, 
					min: minimum
				});
			}
		}
	}, 
	join: {
		header: {
			text: 'Join Game Options'
		}, 
		button: {
			text: 'Join'
		}, 
		options: [ 'Screen Name', 'Password', 'Color', 'Skin',    '1st Ability', '2nd Ability', '3rd Ability', 'Team', 'Auto Assign' ], 
		values:  [ 'text',        'text',     'list',  '3 radio', '2 radio',     '2 radio',     '2 radio',     'list', '1 radio'     ], 
		units: [  ], 
		editTexts: function() {
			{ // Password
				let passwordInput = document.getElementById('Password Input');
				socket.emit('Ask Permission', { pass: passwordInput.value, info: game.info }); // Initialize game as a player
				passwordInput.addEventListener('change', function() {
					socket.emit('Ask Permission', { pass: passwordInput.value, info: game.info }); // Initialize game as a player
				});
				if (game.info.protected == false || socket.id == game.info.host) { // If game is not password protected or player is host
					let passInput = document.getElementById('Password Input'); // Remove Password Field
					let cell = passInput.parentNode;
					let row = cell.parentNode;
					row.parentNode.removeChild(row);
					let rows = document.getElementById('Menu Body').children; // Reset Row Coloration
					for (let i = 0; i < rows.length; i++) {
						let row = rows[i];
						row.style.backgroundColor = 'rgb(' + menus.rows.color.r + ', ' + menus.rows.color.g + ', ' + menus.rows.color.b + ')';
						if (i % 2 == 0) {
							row.style.backgroundColor = 'rgb(' + (menus.rows.color.r - 15) + ', ' + (menus.rows.color.g - 15) + ', ' + (menus.rows.color.b - 15) + ')';
						}
					}
				}
			}
		}, 
		editLists: function() {
			{ // Color
				let colorInput = document.getElementById('Color Input');
				if (game.info.mode != 'skm' && game.info.mode != 'ctf' && game.info.mode != 'inf') { // If not a team mode + inf
					var colorNames = [];
					var options = [];
					var colorLength = 0;
					for (let i in orgColors[game.world.color]) {
						colorLength++;
					}
					let i = 0;
					for (let j in orgColors[game.world.color]) {
						let option;
						if (colorInput.options.length < colorLength) { // If options not already created
							option = document.createElement('option');
							colorInput.appendChild(option);
						} else { // If options already created
							option = colorInput.options[i];
						}
						option.style.backgroundColor = 'rgb(' + orgColors[game.world.color][j].r + ', ' + orgColors[game.world.color][j].g + ', ' + orgColors[game.world.color][j].b + ')';
						option.style.color = 'rgb(0, 0, 0)';
						option.innerHTML = j[0].toUpperCase() + j.slice(1);
						i++;
					}
				} else {
					if (colorInput != undefined) { // If color input not already removed
						let cell = colorInput.parentNode;
						let row = cell.parentNode;
						row.parentNode.removeChild(row); // Remove color row if is a team mode
						let rows = document.getElementById('Menu Body').children;
						for (let i = 0; i < rows.length; i++) { // Reset row coloration
							let row = rows[i];
							row.style.backgroundColor = 'rgb(' + menus.rows.color.r + ', ' + menus.rows.color.g + ', ' + menus.rows.color.b + ')';
							if (i % 2 == 0) {
								row.style.backgroundColor = 'rgb(' + (menus.rows.color.r - 15) + ', ' + (menus.rows.color.g - 15) + ', ' + (menus.rows.color.b - 15) + ')';
							}
						}
					}
				}
			}
			{ // Team
				for (let j = 0; j < games.length; j++) { // Update game (Normally occurs in thesocket.js @ socket.on('Game')); Used for team option updates
					if (games[j].info.host == game.info.host) { // Identify game
						game = games[j];
						break;
					}
				}
				let teamInput = document.getElementById('Team Input');
				if (teamInput != undefined) { // If team option not already removed
					if (game.info.mode != 'skm' && game.info.mode != 'ctf') { // If not a team mode
						let cell = teamInput.parentNode;
						let row = cell.parentNode;
						row.parentNode.removeChild(row); // Remove team option
						let rows = document.getElementById('Menu Body').children; // Reset row coloration
						for (let i = 0; i < rows.length; i++) {
							let row = rows[i];
							row.style.backgroundColor = 'rgb(' + menus.rows.color.r + ', ' + menus.rows.color.g + ', ' + menus.rows.color.b + ')';
							if (i % 2 == 0) {
								row.style.backgroundColor = 'rgb(' + (menus.rows.color.r - 15) + ', ' + (menus.rows.color.g - 15) + ', ' + (menus.rows.color.b - 15) + ')';
							}
						}
					} else { // If a team mode
						for (let i = 0; i < game.teams.length; i++) {
							let option;
							if (teamInput.options.length < game.teams.length) {
								option = document.createElement('option');
								teamInput.appendChild(option);
							} else {
								option = teamInput.options[i];
							}
							option.value = teamColors[i];
							option.innerHTML = teamColors[i][0].toUpperCase() + teamColors[i].slice(1) + ': ' + game.teams[i].length;
						}
					}
				}
			}
		}, 
		editRadios: function() {
			{ // Skins
				for (let i = 0; i < skins.length; i++) { // i < number of skin options
					let skinInput = document.getElementById('Skin Input ' + i);
					let cell = skinInput.parentNode;
					let name = document.createElement('p');
					name.innerHTML = skins[i][0].toUpperCase() + skins[i].slice(1);
					name.style.display = 'inline';
					name.style.margin = '0px';
					name.style.fontFamily = menus.text.font;
					name.style.fontSize = menus.text.size - 2 + 'px';
					name.style.color = 'rgb(' + menus.text.color.r + ', ' + menus.text.color.g + ', ' + menus.text.color.b + ')';
					cell.insertBefore(name, cell.getElementsByTagName('div')[2 * i + 1]); // Insert name before the div line break
				}
			}
			{ // Ability Selection
				if (game.info.mode == 'ffa' || game.info.mode == 'skm' || game.info.mode == 'srv' || game.info.mode == 'kth') { // FFA, SKM, SRV, and KTH all use standard ability set
					for (let i = 0; i < 3; i++) {
						let ordinal;
						if (i == 0) {
							ordinal = '1st';
						} else if (i == 1) {
							ordinal = '2nd';
						} else if (i == 2) {
							ordinal = '3rd';
						}
						for (let j = 0; j < 2; j++) {
							let abilityInput = document.getElementById(ordinal + ' Ability Input ' + j);
							var cell = abilityInput.parentNode;
							for (let k in ability) {
								if (ability[k] != undefined && k != 'tag') {
									if (ability[k].i == i && ability[k].j == j) {
										let name = document.createElement('p');
										name.innerHTML = k[0].toUpperCase() + k.slice(1);
										name.style.display = 'inline';
										name.style.margin = '0px';
										name.style.fontFamily = menus.text.font;
										name.style.fontSize = menus.text.size - 2 + 'px';
										name.style.color = 'rgb(' + menus.text.color.r + ', ' + menus.text.color.g + ', ' + menus.text.color.b + ')';
										cell.insertBefore(name, cell.getElementsByTagName('div')[2 * j + 1]); // Insert name before the div line break
									}
								}
							}
						}
					}
				} else if (game.info.mode == 'inf') { // INF uses 'tag'
					for (let i = 0; i < 3; i++) {
						let ordinal;
						if (i == 0) {
							ordinal = '1st';
						} else if (i == 1) {
							ordinal = '2nd';
						} else if (i == 2) {
							ordinal = '3rd';
						}
						let row = document.getElementById(ordinal + ' Ability Input 0').parentNode.parentNode; // Input is first radio button; Input parent is cell
						row.parentNode.removeChild(row);
						let rows = document.getElementById('Menu Body').children; // Reset Row Coloration
						for (let i = 0; i < rows.length; i++) {
							let row = rows[i];
							row.style.backgroundColor = 'rgb(' + menus.rows.color.r + ', ' + menus.rows.color.g + ', ' + menus.rows.color.b + ')';
							if (i % 2 == 0) {
								row.style.backgroundColor = 'rgb(' + (menus.rows.color.r - 15) + ', ' + (menus.rows.color.g - 15) + ', ' + (menus.rows.color.b - 15) + ')';
							}
						}
					}
				}
			}
			{ // Auto Assign
				let autoInput = document.getElementById('Auto Assign Input 0');
				if (game.info.mode != 'skm' && game.info.mode != 'ctf') { // If not a team game
					let cell = autoInput.parentNode;
					let row = cell.parentNode;
					row.parentNode.removeChild(row);
					let rows = document.getElementById('Menu Body').children; // Reset Row Coloration
					for (let i = 0; i < rows.length; i++) {
						let row = rows[i];
						row.style.backgroundColor = 'rgb(' + menus.rows.color.r + ', ' + menus.rows.color.g + ', ' + menus.rows.color.b + ')';
						if (i % 2 == 0) {
							row.style.backgroundColor = 'rgb(' + (menus.rows.color.r - 15) + ', ' + (menus.rows.color.g - 15) + ', ' + (menus.rows.color.b - 15) + ')';
						}
					}
				} else { // If a team game
					autoInput.addEventListener('click', function() {
						let teamInput = document.getElementById('Team Input');
						if (autoInput.value == true) {
							teamInput.disabled = true;
						} else {
							teamInput.disabled = false;
						}
					});
				}
			}
		}, 
		submit: function() {
			var ok = true; // Check for inputs' validities
			{ // Screen Name
				var name = document.getElementById('Screen Name Input').value;
				if (name == '' || name == undefined || name == null) {
					ok = false;
					alert('Screen name cannot be left empty');
				}
				for (let i = 0; i < game.info.count; i++) { // Requires game to be updated (in renderMenu(datA))
					if (name == game.board.list[i].name) { // Name cannot match another player's name
						ok = false;
						alert('Name matches that of another player');
						break;
					}
				}
			}
			{ // Skins
				let skin = 'none';
				let values = [];
				for (let i = 0; i < skins.length; i++) {
					if (document.getElementById('Skin Input ' + i).value == true) {
						for (let j = 0; j < values.length; j++) {
							if (values[j] == true) {
								ok = false;
								alert('Only one skin can be selected');
								break;
							}
						}
						values[i] = true;
					} else {
						values[i] = false;
					}
				}
			}
			{ // Abilities
				if (game.info.mode == 'ffa' || game.info.mode == 'skm' || game.info.mode == 'srv' || game.info.mode == 'kth') { // FFA, SKM, SRV, and KTH all use standard ability set
					var extend = document.getElementById('1st Ability Input 0');
					var compress = document.getElementById('1st Ability Input 1');
					var immortality = document.getElementById('2nd Ability Input 0');
					var freeze = document.getElementById('2nd Ability Input 1');
					var neutralize = document.getElementById('3rd Ability Input 0');
					var toxin = document.getElementById('3rd Ability Input 1');
					if (extend.value == false && compress.value == false || immortality.value == false && freeze.value == false || neutralize.value == false && toxin.value == false) { // If both false
						ok = false;
						alert('Please select three abilities');
					} else if (extend.value == true && compress.value == true || immortality.value == true && freeze.value == true || neutralize.value == true && toxin.value == true) { // If both true
						ok = false;
						alert('Only one ability of a type can be selected');
					}
				} else if (game.info.mode == 'ctf' || game.info.mode == 'inf') {

				}
			}
			{ // Team
				if (game.info.mode == 'skm' || game.info.mode == 'ctf') { // If is a team game
					let auto = document.getElementById('Auto Assign Input 0').value;
					if (auto != true) {
						let team = document.getElementById('Team Input').value.toLowerCase();
						for (let i = 0; i < game.teams.length; i++) {
							if (i == teamColors.indexOf(team)) {
								continue;
							}
							if (game.teams[teamColors.indexOf(team)].length > game.teams[i].length) {
								if (org != undefined && org.team == team && typeof team == 'string') { // If player is already on loaded team
									break; // Allow spawn
								}
								ok = false;
								alert('Cannot join ' + team + ' team because it already has more players than ' + teamColors[i]);
								break;
							}
						}
					}
				}
			}
			{ // Player Cap
				if (game.players.length >= game.info.cap) {
					ok = false;
					alert('Game is at maximum player capacity');
				}
			}
			{ // Game Closed
				let closed = true;
				for (let i = 0; i < games.length; i++) {
					if (games[i].info.host == game.info.host) {
						closed = false;
						break;
					}
				}
				if (closed == true) {
					ok = false;
					alert('The game has closed');
					renderTitle();
				}
			}
			{ // Password
				socket.emit('Check Permission', { title: game.info.title, type: 'join' });
				socket.on('Permission Denied', deniedJoin);
				socket.on('Permission Granted', grantedJoin);
				function deniedJoin(datA) {
					if (datA.type == 'join') { // 'type' is necessary so won't run spectate code when joining game
						ok = false;
						let password = document.getElementById('Password Input').value;
						if (password == '' || typeof password != 'string') {
							alert('A password is required for this game');
						} else {
							alert('Password is invalid');
						}
					}
					socket.removeListener('Permission Denied', deniedJoin);
				}
				function grantedJoin(datA) {
					if (datA.type == 'join') { // 'type' is necessary so won't run spectate code when joining game
						if (ok == true) { // Inside 'Permission Granted' so can only be triggered once 'Permission Granted' has been received
							// Leaderboard
							game.board.list.push({
								player: socket.id, 
								name: name, 
								kills: 0, 
								deaths: 0, 
								score: 0, 
								wins: 0
							});
							orderBoard(game.board.list);
							socket.emit('Board', game.board); // Must be before spawn because only runs when first entering server, and spawn() runs on respawn as well
							// Abilities
							if (game.info.mode == 'ffa' || game.info.mode == 'skm' || game.info.mode == 'srv' || game.info.mode == 'kth') { // FFA, SKM, SRV, and KTH all use standard ability set
								ability.tag.activated = false;
								ability.tag.can = false;
								if (extend.value == true) {
									ability.extend.activated = true;
									ability.extend.can = true;
									ability.compress.activated = false;
									ability.compress.can = false;
								} else if (compress.value == true) {
									ability.compress.activated = true;
									ability.compress.can = true;
									ability.extend.activated = false;
									ability.extend.can = false;
								}
								if (immortality.value == true) {
									ability.immortality.activated = true;
									ability.immortality.can = true;
									ability.freeze.activated = false;
									ability.freeze.can = false;
								} else if (freeze.value == true) {
									ability.freeze.activated = true;
									ability.freeze.can = true;
									ability.immortality.activated = false;
									ability.immortality.can = false;
								}
								if (neutralize.value == true) {
									ability.neutralize.activated = true;
									ability.neutralize.can = true;
									ability.toxin.activated = false;
									ability.toxin.can = false;
								} else if (toxin.value == true) {
									ability.toxin.activated = true;
									ability.toxin.can = true;
									ability.neutralize.activated = false;
									ability.neutralize.can = false;
								}
								ability.spore.activated = true;
								ability.spore.can = true;
								ability.secrete.activated = true;
								ability.secrete.can = false;
								for (let i = 0; i < ability.shoot.value.length; i++) {
									ability.shoot.can[i] = true;
									ability.shoot.value[i] = false;
								}
							} else if (game.info.mode == 'inf') {
								ability.tag.activated = true;
								ability.tag.can = true;
								ability.extend.activated = false;
								ability.extend.can = false;
								ability.compress.activated = false;
								ability.compress.can = false;
								ability.immortality.activated = false;
								ability.immortality.can = false;
								ability.freeze.activated = false;
								ability.freeze.can = false;
								ability.neutralize.activated = false;
								ability.neutralize.can = false;
								ability.toxin.activated = false;
								ability.toxin.can = false;
								ability.spore.activated = false;
								ability.spore.can = false;
								ability.secrete.activated = false;
								ability.secrete.can = false;
								for (let i = 0; i < ability.shoot.value.length; i++) {
									if (i == ability.tag.i) {
										ability.shoot.can[i] = true;
									} else {
										ability.shoot.can[i] = false;
									}
									ability.shoot.value[i] = false;
								}
							}
							// Skin
							let skin = 'none';
							for (let i = 0; i < skins.length; i++) {
								if (document.getElementById('Skin Input ' + i).value == true) {
									skin = skins[i];
								}
							}
							// Team
							if (game.info.mode == 'skm' || game.info.mode == 'ctf') { // If is a team game
								var team;
								var auto = document.getElementById('Auto Assign Input 0').value;
								if (auto != true) { // If auto assign is not selected
									team = document.getElementById('Team Input').value;
								} else { // If auto assign is selected
									let indices = [];
									let minimum = Infinity;
									for (let i = 0 ; i < game.teams.length; i++) {
										if (game.teams[i].length < minimum) { // If length is less than minimum
											minimum = game.teams[i].length; // Set length as new minimum
											indices = [i]; // Clear indices and push i
										} else if (game.teams[i].length == minimum) {
											indices.push(i);
										}
									}
									team = teamColors[indices[floor(random(0, indices.length))]];
								}
								for (let i = 0; i < teamColors.length; i++) {
									if (team == teamColors[i]) {
										game.teams[i].push(socket.id); // Add player to selected team
										socket.emit('Teams', { teams: game.teams, host: game.info.host }); // Host is for identification
										break;
									}
								}
							}
							// Color
							if (game.info.mode == 'inf') { // If inf mode
								var color = teamColorDef.green; // All players healthy by default
							} else if (game.info.mode != 'skm' && game.info.mode != 'ctf') { // If is not a team game
								var color = document.getElementById('Color Input').value.toLowerCase();
							} else {
								var color = teamColorDef[team]; // Color must be after Team
							}
							// Initialize
							clearInterval(title.interval);
							if (game.rounds.util == true) {
								if (game.rounds.waiting == true) {
									initialize(game, { spectate: false, color: orgColors[game.world.color][color], skin: skin, team: team });
								} else {
									initialize(game, { spectate: true, color: orgColors[game.world.color][color], skin: skin, team: team });
								}
							} else {
								initialize(game, { spectate: false, color: orgColors[game.world.color][color], skin: skin, team: team });
							}
						}
					}
					socket.removeListener('Permission Granted', grantedJoin);
				}
			}
		}
	}, 
	spectate: {
		header: {
			text: 'Spectate Game Options'
		}, 
		button: {
			text: 'Spectate'
		}, 
		options: [ 'Screen Name', 'Password' ], 
		values:  [ 'text',        'text'     ], 
		units: [ undefined, undefined ], 
		editTexts: function() {
			// Password
			let passwordInput = document.getElementById('Password Input');
			socket.emit('Ask Permission', { pass: passwordInput.value, info: game.info }); // Initialize game as a player
			passwordInput.addEventListener('change', function() {
				socket.emit('Ask Permission', { pass: passwordInput.value, info: game.info }); // Initialize game as a player
			});
			if (game.info.protected == false || socket.id == game.info.host) { // If game is not password protected or player is host
				let passInput = document.getElementById('Password Input'); // Remove Password Field
				let cell = passInput.parentNode;
				let row = cell.parentNode;
				row.parentNode.removeChild(row);
				let rows = document.getElementById('Menu Body').children; // Reset Row Coloration
				for (let i = 0; i < rows.length; i++) {
					let row = rows[i];
					row.style.backgroundColor = 'rgb(' + menus.rows.color.r + ', ' + menus.rows.color.g + ', ' + menus.rows.color.b + ')';
					if (i % 2 == 0) {
						row.style.backgroundColor = 'rgb(' + (menus.rows.color.r - 15) + ', ' + (menus.rows.color.g - 15) + ', ' + (menus.rows.color.b - 15) + ')';
					}
				}
			}
		}, 
		submit: function() {
			var ok = true;
			{ // Game Closed
				let closed = true;
				for (let i = 0; i < games.length; i++) {
					if (games[i].info.host == game.info.host) {
						closed = false;
						break;
					}
				}
				if (closed == true) {
					ok = false;
					alert('The game has closed');
					renderTitle();
				}
			}
			{ // Screen Name
				var name = document.getElementById('Screen Name Input').value;
				if (name == '' || name == undefined || name == null) {
					ok = false;
					alert('Screen name cannot be left empty');
				}
				for (let i = 0; i < game.info.count; i++) { // Requires game to be updated (in renderMenu(datA))
					if (name == game.board.list[i].name) { // Name cannot match another player's name
						ok = false;
						alert('Name matches that of another player');
						break;
					}
				}
			}
			{ // Password
				socket.emit('Check Permission', { title: game.info.title, type: 'spectate' });
				socket.on('Permission Denied', deniedSpectate);
				socket.on('Permission Granted', grantedSpectate);
				function deniedSpectate(datA) {
					if (datA.type == 'spectate') { // 'type' is necessary so won't run join code when spectating game
						ok = false;
						let password = document.getElementById('Password Input').value;
						if (password == '' || typeof password != 'string') {
							alert('A password is required for this game');
						} else {
							alert('Password is invalid');
						}
					}
					socket.removeListener('Permission Denied', deniedSpectate);
				}
				function grantedSpectate(datA) {
					if (datA.type == 'spectate') { // 'type' is necessary so won't run join code when spectating game
						if (ok == true) { // Inside 'Permission Granted' so can only be triggered once 'Permission Granted' has been received
							// Leaderboard
							game.board.list.push({ // Add player to leaderboard
								player: socket.id, 
								name: name, 
								kills: 0, 
								deaths: 0, 
								score: 0, 
								wins: 0
							});
							orderBoard(game.board.list);
							socket.emit('Board', game.board); // Must be before spawn because only runs when first entering server, and spawn() runs on respawn as well
							// Initialize
							clearInterval(title.interval);
							initialize(game, { spectate: true, color: undefined, skin: undefined });
						}
					}
					socket.removeListener('Permission Granted', grantedSpectate);
				}
			}
		}
	}, 
	respawn: {
		header: {
			text: 'Respawn Options'
		}, 
		button: {
			text: 'Respawn'
		}, 
		options: [ 'Color', 'Skin',    '1st Ability', '2nd Ability', '3rd Ability', 'Team', 'Auto Assign' ], 
		values:  [ 'list',  '3 radio', '2 radio',     '2 radio',     '2 radio',     'list', '1 radio'     ], 
		units: [  ], 
		editLists: function() {
			{ // Color
				let colorInput = document.getElementById('Color Input');
				if (game.info.mode != 'skm' && game.info.mode != 'ctf' && game.info.mode != 'inf') { // If not a team mode + inf
					var colorNames = [];
					var options = [];
					var colorLength = 0;
					for (let i in orgColors[game.world.color]) {
						colorLength++;
					}
					let i = 0;
					for (let j in orgColors[game.world.color]) {
						let option;
						if (colorInput.options.length < colorLength) { // If options not already created
							option = document.createElement('option');
							colorInput.appendChild(option);
						} else { // If options already created
							option = colorInput.options[i];
						}
						option.style.backgroundColor = 'rgb(' + orgColors[game.world.color][j].r + ', ' + orgColors[game.world.color][j].g + ', ' + orgColors[game.world.color][j].b + ')';
						option.style.color = 'rgb(0, 0, 0)';
						option.innerHTML = j[0].toUpperCase() + j.slice(1);
						if (org.color != undefined) {
							if (orgColors[game.world.color][j].r == org.color.r && orgColors[game.world.color][j].g == org.color.g && orgColors[game.world.color][j].b == org.color.b) { // If is current org color
								option.selected = 'selected'; // Pre-Select current org color
							}
						}
						i++;
					}
				} else {
					if (colorInput != undefined) { // If color input not already removed
						let cell = colorInput.parentNode;
						let row = cell.parentNode;
						row.parentNode.removeChild(row); // Remove color row if is a team mode
						let rows = document.getElementById('Menu Body').children;
						for (let i = 0; i < rows.length; i++) { // Reset row coloration
							let row = rows[i];
							row.style.backgroundColor = 'rgb(' + menus.rows.color.r + ', ' + menus.rows.color.g + ', ' + menus.rows.color.b + ')';
							if (i % 2 == 0) {
								row.style.backgroundColor = 'rgb(' + (menus.rows.color.r - 15) + ', ' + (menus.rows.color.g - 15) + ', ' + (menus.rows.color.b - 15) + ')';
							}
						}
					}
				}
			}
			{ // Team
				for (let j = 0; j < games.length; j++) { // Update game (Normally occurs in thesocket.js socket.on('Game')); Used for team option updates
					if (games[j].info.host == game.info.host) { // Identify game
						game = games[j];
						break;
					}
				}
				let teamInput = document.getElementById('Team Input');
				if (teamInput != undefined) { // If team option not already removed
					if (game.info.mode != 'skm' && game.info.mode != 'ctf' && teamInput != undefined) { // If not a team mode
						let cell = teamInput.parentNode;
						let row = cell.parentNode;
						row.parentNode.removeChild(row); // Remove team option
						let rows = document.getElementById('Menu Body').children; // Reset row coloration
						for (let i = 0; i < rows.length; i++) {
							let row = rows[i];
							row.style.backgroundColor = 'rgb(' + menus.rows.color.r + ', ' + menus.rows.color.g + ', ' + menus.rows.color.b + ')';
							if (i % 2 == 0) {
								row.style.backgroundColor = 'rgb(' + (menus.rows.color.r - 15) + ', ' + (menus.rows.color.g - 15) + ', ' + (menus.rows.color.b - 15) + ')';
							}
						}
					} else { // If a team mode
						for (let i = 0; i < game.teams.length; i++) {
							let option;
							if (teamInput.options.length < game.teams.length) { // If options not yet created
								option = document.createElement('option');
								teamInput.appendChild(option);
								if (i == teamColors.indexOf(org.team)) {
									option.selected = 'selected';
								}
							} else { // If updating previously created options
								option = teamInput.options[i];
							}
							option.value = teamColors[i];
							option.innerHTML = teamColors[i][0].toUpperCase() + teamColors[i].slice(1) + ': ' + game.teams[i].length;
						}
					}
				}
			}
		}, 
		editRadios: function() {
			{ // Skins
				for (let i = 0; i < skins.length; i++) { // i < number of skin options
					let skinInput = document.getElementById('Skin Input ' + i);
					let cell = skinInput.parentNode;
					let name = document.createElement('p');
					name.innerHTML = skins[i][0].toUpperCase() + skins[i].slice(1);
					name.style.display = 'inline';
					name.style.margin = '0px';
					name.style.fontFamily = menus.text.font;
					name.style.fontSize = menus.text.size - 2 + 'px';
					name.style.color = 'rgb(' + menus.text.color.r + ', ' + menus.text.color.g + ', ' + menus.text.color.b + ')';
					cell.insertBefore(name, cell.getElementsByTagName('div')[2 * i + 1]); // Insert name before the div line break
					if (org.skin == skins[i]) {
						skinInput.value = true;
						skinInput.style.backgroundColor = 'rgb(' + menus.radios.selectColor.r + ', ' + menus.radios.selectColor.g + ', ' + menus.radios.selectColor.b + ')';
					}
				}
			}
			{ // Ability Selection
				if (game.info.mode == 'ffa' || game.info.mode == 'skm' || game.info.mode == 'srv' || game.info.mode == 'kth') { // FFA, SKM, SRV, and KTH all use standard ability set
					for (let i = 0; i < 3; i++) {
						let ordinal;
						if (i == 0) {
							ordinal = '1st';
						} else if (i == 1) {
							ordinal = '2nd';
						} else if (i == 2) {
							ordinal = '3rd';
						}
						for (let j = 0; j < 2; j++) {
							let abilityInput = document.getElementById(ordinal + ' Ability Input ' + j);
							var cell = abilityInput.parentNode;
							for (let k in ability) {
								if (ability[k] != undefined && k != 'tag') {
									if (ability[k].i == i && ability[k].j == j) {
										let name = document.createElement('p');
										name.innerHTML = k[0].toUpperCase() + k.slice(1);
										name.style.display = 'inline';
										name.style.margin = '0px';
										name.style.fontFamily = menus.text.font;
										name.style.fontSize = menus.text.size - 2 + 'px';
										name.style.color = 'rgb(' + menus.text.color.r + ', ' + menus.text.color.g + ', ' + menus.text.color.b + ')';
										cell.insertBefore(name, cell.getElementsByTagName('div')[2 * j + 1]); // Insert name before the div line break
										if (ability[k].activated == true) { // Load previous ability configuration to default
											abilityInput.value = true;
											abilityInput.style.backgroundColor = 'rgb(' + menus.radios.selectColor.r + ', ' + menus.radios.selectColor.g + ', ' + menus.radios.selectColor.b + ')';
										} else if (ability[k].activated == false) {
											abilityInput.value = false;
											abilityInput.style.backgroundColor = 'rgb(' + menus.radios.backgroundColor.r + ', ' + menus.radios.backgroundColor.g + ', ' + menus.radios.backgroundColor.b + ')';
										}
									}
								}
							}
						}
					}
				} else if (game.info.mode == 'inf') { // INF uses 'tag'
					for (let i = 0; i < 3; i++) {
						let ordinal;
						if (i == 0) {
							ordinal = '1st';
						} else if (i == 1) {
							ordinal = '2nd';
						} else if (i == 2) {
							ordinal = '3rd';
						}
						let row = document.getElementById(ordinal + ' Ability Input 0').parentNode.parentNode; // Input is first radio button; Input parent is cell
						row.parentNode.removeChild(row); // Remove ability selections
						let rows = document.getElementById('Menu Body').children; // Reset Row Coloration
						for (let i = 0; i < rows.length; i++) {
							let row = rows[i];
							row.style.backgroundColor = 'rgb(' + menus.rows.color.r + ', ' + menus.rows.color.g + ', ' + menus.rows.color.b + ')';
							if (i % 2 == 0) {
								row.style.backgroundColor = 'rgb(' + (menus.rows.color.r - 15) + ', ' + (menus.rows.color.g - 15) + ', ' + (menus.rows.color.b - 15) + ')';
							}
						}
					}
				}
			}
			{ // Auto Assign
				let autoInput = document.getElementById('Auto Assign Input 0');
				if (game.info.mode != 'skm' && game.info.mode != 'ctf') { // If not a team game
					let cell = autoInput.parentNode;
					let row = cell.parentNode;
					row.parentNode.removeChild(row);
					let rows = document.getElementById('Menu Body').children; // Reset Row Coloration
					for (let i = 0; i < rows.length; i++) {
						let row = rows[i];
						row.style.backgroundColor = 'rgb(' + menus.rows.color.r + ', ' + menus.rows.color.g + ', ' + menus.rows.color.b + ')';
						if (i % 2 == 0) {
							row.style.backgroundColor = 'rgb(' + (menus.rows.color.r - 15) + ', ' + (menus.rows.color.g - 15) + ', ' + (menus.rows.color.b - 15) + ')';
						}
					}
				} else { // If a team game
					autoInput.addEventListener('click', function() {
						let teamInput = document.getElementById('Team Input');
						if (autoInput.value == true) {
							teamInput.disabled = true;
						} else {
							teamInput.disabled = false;
						}
					});
				}
			}
		}, 
		submit: function() {
			var ok = true;
			{ // Skins
				let skin = 'none';
				let values = [];
				for (let i = 0; i < skins.length; i++) {
					if (document.getElementById('Skin Input ' + i).value == true) {
						for (let j = 0; j < values.length; j++) {
							if (values[j] == true) {
								ok = false;
								alert('Only one skin can be selected');
								break;
							}
						}
						values[i] = true;
					} else {
						values[i] = false;
					}
				}
			}
			{ // Abilities
				if (game.info.mode == 'ffa' || game.info.mode == 'skm' || game.info.mode == 'srv' || game.info.mode == 'kth') { // FFA, SKM, SRV, and KTH all use standard ability set
					var extend = document.getElementById('1st Ability Input 0');
					var compress = document.getElementById('1st Ability Input 1');
					var immortality = document.getElementById('2nd Ability Input 0');
					var freeze = document.getElementById('2nd Ability Input 1');
					var neutralize = document.getElementById('3rd Ability Input 0');
					var toxin = document.getElementById('3rd Ability Input 1');
					if (extend.value == false && compress.value == false || immortality.value == false && freeze.value == false || neutralize.value == false && toxin.value == false) { // If both false
						ok = false;
						alert('Please select three abilities');
					} else if (extend.value == true && compress.value == true || immortality.value == true && freeze.value == true || neutralize.value == true && toxin.value == true) { // If both true
						ok = false;
						alert('Only one ability of a type can be selected');
					}
				} else if (game.info.mode == 'inf') { // INF uses tag

				}
			}
			{ // Team
				if (game.info.mode == 'skm' || game.info.mode == 'ctf') { // If is a team game
					var team;
					var auto = document.getElementById('Auto Assign Input 0').value;
					if (auto != true) { // If auto assign is not selected
						team = document.getElementById('Team Input').value;
						for (let i = 0; i < game.teams.length; i++) {
							if (i == teamColors.indexOf(team)) {
								continue;
							}
							if (game.teams[teamColors.indexOf(team)].length > game.teams[i].length) {
								if (org.team == team && typeof team == 'string') { // If player is already on loaded team
									break; // Allow spawn
								}
								ok = false;
								alert('Cannot join ' + team + ' team because it already has more players than ' + teamColors[i]);
								break;
							}
						}
					} else { // If auto assign is selected
						let indices = [];
						let minimum = Infinity;
						for (let i = 0 ; i < game.teams.length; i++) {
							let l = game.teams[i].length;
							if (game.teams[i].indexOf(socket.id) != -1) { // If player is on given team
								l--; // Do not include player as part of the team, so if even numbers before, will replace back on the same team and not add extra to other team
							}
							if (l < minimum) { // If length is less than minimum
								minimum = l; // Set length as new minimum
								indices = [i]; // Clear indices and push i
							} else if (l == minimum) {
								indices.push(i);
							}
						}
						team = teamColors[indices[floor(random(0, indices.length))]];
					}
				}
			}
			{ // Game Closed
				let closed = true;
				for (let i = 0; i < games.length; i++) {
					if (games[i].info.host == game.info.host) {
						closed = false;
						break;
					}
				}
				if (closed == true) {
					ok = false;
					alert('The game has closed');
					renderTitle();
				}
			}
			if (ok == true) {
				socket.emit('Spectator Spawned', game);
				// Abilities
				if (game.info.mode == 'ffa' || game.info.mode == 'skm' || game.info.mode == 'srv' || game.info.mode == 'kth') { // FFA, SKM, SRV, and KTH all use standard ability set
					if (extend.value == true) {
						ability.extend.activated = true;
						ability.extend.can = true;
						ability.compress.activated = false;
						ability.compress.can = false;
					} else if (compress.value == true) {
						ability.compress.activated = true;
						ability.compress.can = true;
						ability.extend.activated = false;
						ability.extend.can = false;
					}
					if (immortality.value == true) {
						ability.immortality.activated = true;
						ability.immortality.can = true;
						ability.freeze.activated = false;
						ability.freeze.can = false;
					} else if (freeze.value == true) {
						ability.freeze.activated = true;
						ability.freeze.can = true;
						ability.immortality.activated = false;
						ability.immortality.can = false;
					}
					if (neutralize.value == true) {
						ability.neutralize.activated = true;
						ability.neutralize.can = true;
						ability.toxin.activated = false;
						ability.toxin.can = false;
					} else if (toxin.value == true) {
						ability.toxin.activated = true;
						ability.toxin.can = true;
						ability.neutralize.activated = false;
						ability.neutralize.can = false;
					}
					ability.spore.activated = true;
					ability.spore.can = true;
					ability.secrete.activated = true;
					ability.secrete.can = false;
				} else if (game.info.mode == 'inf') {
					ability.extend.activated = false;
					ability.extend.can = false;
					ability.compress.activated = false;
					ability.compress.can = false;
					ability.immortality.activated = false;
					ability.immortality.can = false;
					ability.freeze.activated = false;
					ability.freeze.can = false;
					ability.neutralize.activated = false;
					ability.neutralize.can = false;
					ability.toxin.activated = false;
					ability.toxin.can = false;
					ability.spore.activated = false;
					ability.spore.can = false;
					ability.secrete.activated = false;
					ability.secrete.can = false;
				}
				// Skin
				let skin = 'none';
				for (let i = 0; i < skins.length; i++) {
					if (document.getElementById('Skin Input ' + i).value == true) {
						skin = skins[i];
					}
				}
				// Team
				if (game.info.mode == 'skm' || game.info.mode == 'ctf') { // If is a team game
					if (org.team != team) { // Only add player to team if not already on team
						game.teams[teamColors.indexOf(team)].push(socket.id); // Add player to selected team
						game.teams[teamColors.indexOf(org.team)].splice(game.teams[teamColors.indexOf(org.team)].indexOf(socket.id), 1);
						socket.emit('Teams', { teams: game.teams, host: game.info.host }); // Host is for identification
					}
				}
				// Color
				if (game.info.mode == 'inf') { // If inf mode
					var color = teamColorDef.green; // All players healthy by default
				} else if (game.info.mode != 'skm' && game.info.mode != 'ctf') { // If is not a team mode	
					var color = document.getElementById('Color Input').value.toLowerCase();
				} else {
					var color = teamColorDef[team]; // Color must be after Team
				}
				// Initialize
				initialize(game, { spectate: false, color: orgColors[game.world.color][color], skin: skin, team: team });
			}
		}
	}, 
	pauseGame: {
		header: {
			text: 'Pause Options'
		}, 
		button: {
			text: 'Return'
		}, 
		options: [ 'Color', 'Skin',    'Name Labels', 'Messages',    'Leave Game' ], 
		values:  [ 'list',  '3 radio', '1 radio'    , '1 radio', 'button'     ], 
		units: [  ], 
		editLists: function() {
			{ // Color
				let colorInput = document.getElementById('Color Input');
				if (game.info.mode != 'skm' && game.info.mode != 'ctf') { // If not a team mode
					var colorNames = [];
					var options = [];
					for (let j in orgColors[game.world.color]) {
						let option = document.createElement('option');
						colorInput.appendChild(option);
						option.style.backgroundColor = 'rgb(' + orgColors[game.world.color][j].r + ', ' + orgColors[game.world.color][j].g + ', ' + orgColors[game.world.color][j].b + ')';
						option.style.color = 'rgb(0, 0, 0)';
						option.innerHTML = j[0].toUpperCase() + j.slice(1);
						if (org.color != undefined) {
							if (orgColors[game.world.color][j].r == org.color.r && orgColors[game.world.color][j].g == org.color.g && orgColors[game.world.color][j].b == org.color.b) { // If is current org color
								option.selected = 'selected'; // Pre-Select current org color
							}
						}
					}
				} else {
					let cell = colorInput.parentNode;
					let row = cell.parentNode;
					row.parentNode.removeChild(row); // Remove color row if is a team mode
					let rows = document.getElementById('Menu Body').children;
					for (let i = 0; i < rows.length; i++) { // Reset row coloration
						let row = rows[i];
						row.style.backgroundColor = 'rgb(' + menus.rows.color.r + ', ' + menus.rows.color.g + ', ' + menus.rows.color.b + ')';
						if (i % 2 == 0) {
							row.style.backgroundColor = 'rgb(' + (menus.rows.color.r - 15) + ', ' + (menus.rows.color.g - 15) + ', ' + (menus.rows.color.b - 15) + ')';
						}
					}
				}
			}
		}, 
		editRadios: function() {
			{ // Skins
				for (let i = 0; i < skins.length; i++) { // i < number of skin options
					let skinInput = document.getElementById('Skin Input ' + i);
					let cell = skinInput.parentNode;
					let name = document.createElement('p');
					name.innerHTML = skins[i][0].toUpperCase() + skins[i].slice(1);
					name.style.display = 'inline';
					name.style.margin = '0px';
					name.style.fontFamily = menus.text.font;
					name.style.fontSize = menus.text.size - 2 + 'px';
					name.style.color = 'rgb(' + menus.text.color.r + ', ' + menus.text.color.g + ', ' + menus.text.color.b + ')';
					cell.insertBefore(name, cell.getElementsByTagName('div')[2 * i + 1]); // Insert name before the div line break
					if (org.skin == skins[i]) {
						skinInput.value = true;
						skinInput.style.backgroundColor = 'rgb(' + menus.radios.selectColor.r + ', ' + menus.radios.selectColor.g + ', ' + menus.radios.selectColor.b + ')';
					}
				}
			}
			{ // Name Labels
				let labelsInput = document.getElementById('Name Labels Input 0');
				if (Labels == true) {
					labelsInput.value = true;
					labelsInput.style.backgroundColor = 'rgb(' + menus.radios.selectColor.r + ', ' + menus.radios.selectColor.g + ', ' + menus.radios.selectColor.b + ')';
				} else if (Labels == false) {
					labelsInput.value = false;
					labelsInput.style.backgroundColor = 'rgb(' + menus.radios.backgroundColor.r + ', ' + menus.radios.backgroundColor.g + ', ' + menus.radios.backgroundColor.b + ')';
				}
			}
			{ // Messages
				let messagesInput = document.getElementById('Messages Input 0');
				if (Messages == true) {
					messagesInput.value = true;
					messagesInput.style.backgroundColor = 'rgb(' + menus.radios.selectColor.r + ', ' + menus.radios.selectColor.g + ', ' + menus.radios.selectColor.b + ')';
				} else if (Messages == false) {
					messagesInput.value = false;
					messagesInput.style.backgroundColor = 'rgb(' + menus.radios.backgroundColor.r + ', ' + menus.radios.backgroundColor.g + ', ' + menus.radios.backgroundColor.b + ')';
				}
			}
		}, 
		editButtons: function() {
			let buttonInput = document.getElementById('Leave Game Input');
			buttonInput.addEventListener('click', function() {
				socket.emit('Leave Game', game);
				clearInterval(org.interval); // Copied from die()
				for (let i in ability) { // Reset Ability Cooldowns
					if (typeof ability[i] == 'object') { // If is a usable ability
						clearTimeout(ability[i].timeout);
						ability[i].value = false;
						ability[i].can = true;
						ability[i].cooling = false;
						ability[i].start = undefined;
						ability[i].end = undefined;
					}
				}
				for (let i = 0; i < 3; i++) { // Reset shoots
					clearTimeout(ability.shoot.timeout[i]);
					ability.shoot.value[i] = false;
					ability.shoot.can[i] = true;
					ability.shoot.spore[i] = undefined;
					ability.shoot.secrete[i] = {};
					ability.shoot.start[i] = undefined;
					ability.shoot.end[i] = undefined;
				}
				for (let i = 0; i < game.board.list.length; i++) {
					if (game.board.list[i].player == socket.id) { // Find player in leaderboard
						game.board.list.splice(i, 1); // Remove player from leaderboard
						orderBoard(game.board.list); // Sort the list
						socket.emit('Board', game.board); // Send updated board to server
						break;
					}
				}
				org = undefined;
				renderTitle();
			});
		}, 
		submit: function() {
			var ok = true;
			{ // Skins
				let skin = 'none';
				let values = [];
				for (let i = 0; i < skins.length; i++) {
					if (document.getElementById('Skin Input ' + i).value == true) {
						for (let j = 0; j < values.length; j++) {
							if (values[j] == true) {
								ok = false;
								alert('Only one skin can be selected');
								break;
							}
						}
						values[i] = true;
					} else {
						values[i] = false;
					}
				}
			}
			{ // Game Closed
				let closed = true;
				for (let i = 0; i < games.length; i++) {
					if (games[i].info.host == game.info.host) {
						closed = false;
						break;
					}
				}
				if (closed == true) {
					ok = false;
					alert('The game has closed');
					renderTitle();
				}
			}
			if (ok == true) {
				{ // Color
					if (game.info.mode != 'skm' && game.info.mode != 'ctf') { // If is not a team mode
						var color = document.getElementById('Color Input').value.toLowerCase();
						org.color = orgColors[game.world.color][color];
					} // Cannot change team in pause menu
				}
				{ // Skin
					let skin = 'none';
					for (let i = 0; i < skins.length; i++) {
						if (document.getElementById('Skin Input ' + i).value == true) {
							skin = skins[i];
						}
					}
					org.skin = skin;
				}
				{ // Name Labels
					let labelsInput = document.getElementById('Name Labels Input 0');
					Labels = labelsInput.value;
				}
				{ // Messages
					let messagesInput = document.getElementById('Messages Input 0');
					Messages = messagesInput.value;
				}
				// Initialize
				var page = document.body.parentNode; // Clear Body
				page.removeChild(document.body);
				body = document.createElement('body');
				page.appendChild(body);
				body.style.overflow = 'hidden'; // Apply Canvas Styling
				body.style.margin = '0px';
				body.style.border = '0px';
				body.style.padding = '0px';
				cnv = createCanvas(window.innerWidth, window.innerHeight); // Create Canvas
				canvas = cnv.elt; // HTML Node is stored in p5 canvas' .elt property
				canvas.style.visibility = 'visible';
				body.appendChild(canvas);
				center = {
					x: width / 2, 
					y: height / 2
				};
				rectMode(CENTER);
				ellipseMode(RADIUS);
				angleMode(DEGREES);
				textAlign(LEFT);
				let skip = false;
				for (let i = 0; i < game.players.length; i++) {
					if (game.players[i] == socket.id) { // If still is a player
						state = 'game';
						skip = true;
						break;
					}
				}
				if (skip == false) {
					for (let i = 0; i < game.spectators.length; i++) {
						if (game.spectators[i] == socket.id) {
							state = 'spectate';
							break;
						}
					}
				}
			}
		}
	}, 
	pauseSpectate: {
		header: {
			text: 'Pause Options'
		}, 
		button: {
			text: 'Return'
		}, 
		options: [ 'Name Labels', 'Messages',    'Leave Game' ], 
		values:  [ '1 radio'    , '1 radio', 'button'     ], 
		units: [  ], 
		editRadios: function() {
			{ // Name Labels
				let labelsInput = document.getElementById('Name Labels Input 0');
				if (Labels == true) {
					labelsInput.value = true;
					labelsInput.style.backgroundColor = 'rgb(' + menus.radios.selectColor.r + ', ' + menus.radios.selectColor.g + ', ' + menus.radios.selectColor.b + ')';
				} else if (Labels == false) {
					labelsInput.value = false;
					labelsInput.style.backgroundColor = 'rgb(' + menus.radios.backgroundColor.r + ', ' + menus.radios.backgroundColor.g + ', ' + menus.radios.backgroundColor.b + ')';
				}
			}
			{ // Messages
				let messagesInput = document.getElementById('Messages Input 0');
				if (Messages == true) {
					messagesInput.value = true;
					messagesInput.style.backgroundColor = 'rgb(' + menus.radios.selectColor.r + ', ' + menus.radios.selectColor.g + ', ' + menus.radios.selectColor.b + ')';
				} else if (Messages == false) {
					messagesInput.value = false;
					messagesInput.style.backgroundColor = 'rgb(' + menus.radios.backgroundColor.r + ', ' + menus.radios.backgroundColor.g + ', ' + menus.radios.backgroundColor.b + ')';
				}
			}
		}, 
		editButtons: function() {
			{ // Leave Game
				let buttonInput = document.getElementById('Leave Game Input');
				buttonInput.addEventListener('click', function() {
					socket.emit('Leave Game', game);
					clearInterval(org.interval); // Copied from die() (Ability resets not necessary for spectate leave)
					for (let i = 0; i < game.board.list.length; i++) {
						if (game.board.list[i].player == socket.id) { // Find player in leaderboard
							game.board.list.splice(i, 1); // Remove player from leaderboard
							orderBoard(game.board.list); // Sort the list
							socket.emit('Board', game.board); // Send updated board to server
							break;
						}
					}
					org = undefined;
					renderTitle();
				});
			}
		}, 
		submit: function() {
			var ok = true;
			{ // Game Closed
				let closed = true;
				for (let i = 0; i < games.length; i++) {
					if (games[i].info.host == game.info.host) {
						closed = false;
						break;
					}
				}
				if (closed == true) {
					ok = false;
					alert('The game has closed');
					renderTitle();
				}
			}
			if (ok == true) {
				{ // Name Labels
					let labelsInput = document.getElementById('Name Labels Input 0');
					if (labelsInput != null) {
						Labels = labelsInput.value;
					}
				}
				{ // Messages
					let messagesInput = document.getElementById('Messages Input 0');
					if (messagesInput != null) {
						Messages = messagesInput.value;
					}
				}
				// Initialize
				var page = document.body.parentNode; // Clear Body
				page.removeChild(document.body);
				body = document.createElement('body');
				page.appendChild(body);
				body.style.overflow = 'hidden'; // Apply Canvas Styling
				body.style.margin = '0px';
				body.style.border = '0px';
				body.style.padding = '0px';
				cnv = createCanvas(window.innerWidth, window.innerHeight); // Create Canvas
				canvas = cnv.elt; // HTML Node is stored in p5 canvas' .elt property
				canvas.style.visibility = 'visible';
				body.appendChild(canvas);
				center = {
					x: width / 2, 
					y: height / 2
				};
				rectMode(CENTER);
				ellipseMode(RADIUS);
				angleMode(DEGREES);
				textAlign(LEFT);
				state = 'spectate';
			}
		}
	}, 
	pauseTutorial: {
		header: {
			text: 'Pause Options'
		}, 
		button: {
			text: 'Return'
		}, 
		options: [ 'Leave Game' ], 
		values:  [ 'button'     ], 
		units: [  ], 
		editButtons: function() {
			{ // Leave Game
				let leaveInput = document.getElementById('Leave Game Input');
				leaveInput.addEventListener('click', function() {
					tutorial.clear();
					ability = new Ability({ player: socket.id }); // Reconstruct in case tutorial caused any problem in ability object
					org = undefined;
					renderTitle();
				});
			}
		}, 
		submit: function() {
			var ok = true;
			if (ok == true) {
				// Initialize
				cnvClear();
				rectMode(CENTER);
				ellipseMode(RADIUS);
				angleMode(DEGREES);
				textAlign(LEFT);
				state = 'tutorial';
			}
		}
	}
};

function renderMenu(typE, datA) {
	var type = typE;
	if (type == 'join' || type == 'spectate' || type == 'respawn') {
		game = datA;
	}
	// Clear Body
	var page = document.body.parentNode;
	page.addEventListener('mouseup', function() {
		button.down = false;
	});
	cnvClear();
	var body = document.body;
	{
		state = type + 'Menu';
		var shade = new Shade();
		body.appendChild(shade.elt);
		var container = document.createElement('div');
		container.style.position = 'fixed';
		container.style.top = '0px';
		container.style.left = '0px';
		container.style.width = '100%';
		container.style.height = '100%';
		body.appendChild(container);
		var header = document.createElement('div');
		container.appendChild(header);
		header.id = type + 'Header';
		header.style.height = menus.header.height + 'px';
		header.style.width = '100%';
		header.style.paddingTop = menus.header.padding + 'px';
		header.style.paddingBottom = menus.header.padding + 'px';
		header.style.backgroundColor = 'rgb(' + menus.header.backgroundColor.r + ', ' + menus.header.backgroundColor.g + ', ' + menus.header.backgroundColor.b + ')';
		var headerText = document.createElement('h2');
		header.appendChild(headerText);
		headerText.style.margin = '0px';
		headerText.style.position = 'relative';
		headerText.style.top = (menus.header.height - menus.header.padding - menus.header.size * 3 / 4) / 2 + 'px';
		headerText.style.color = 'rgb(' + menus.header.color.r + ', ' + menus.header.color.g + ', ' + menus.header.color.b + ')';
		headerText.style.fontFamily = menus.header.font;
		headerText.style.fontSize = menus.header.size + 'px';
		headerText.style.textAlign = 'center';
		headerText.style.fontWeight = menus.header.weight;
		headerText.innerHTML = menus[type].header.text;
		var content = document.createElement('div');
		container.appendChild(content);
		content.style.paddingBottom = menus.footer.height + 'px';
		content.style.overflow = 'auto';
		var table = document.createElement('table');
		content.appendChild(table);
		table.id = type + 'Table';
		table.style.width = '100%';
		table.style.margin ='0px';
		table.style.marginTop = menus.top + 'px';
		table.style.padding = menus.padding + 'px';
		table.style.backgroundColor = 'rgb(' + menus.color.r + ', ' + menus.color.g + ', ' + menus.color.b + ')';
		table.style.opacity = '.9';
		table.style.borderCollapse = 'collapse';
		table.style.borderColor = 'rgb(' + menus.border.color.r + ', ' + menus.border.color.g + ', ' + menus.border.color.b + ')';
		table.style.borderWidth = menus.border.width + 'px';
		table.style.borderStyle = menus.border.style;
		var tableBody = document.createElement('tbody');
		tableBody.id = 'Menu Body';
		tableBody.style.fontFamily = menus.text.font;
		tableBody.style.fontSize = menus.text.size + 'pt';
		table.appendChild(tableBody);
		for (let i = 0; i < menus[type].options.length; i++) {
			let row = tableBody.insertRow(-1);
			row.row = i;
			row.id = i;
			row.style.height = menus.rows.height + 'px';
			row.style.backgroundColor = 'rgb(' + menus.rows.color.r + ', ' + menus.rows.color.g + ', ' + menus.rows.color.b + ')';
			if (i % 2 == 0) {
				row.style.backgroundColor = 'rgb(' + (menus.rows.color.r - 15) + ', ' + (menus.rows.color.g - 15) + ', ' + (menus.rows.color.b - 15) + ')';
			}
			row.style.width = 'inherit';
			row.style.margin = menus.rows.margin + 'px';
			row.style.padding = menus.rows.padding + 'px';
			for (let j = 0; j < menus.cells.count; j++) {
				let cell = row.insertCell(j);
				cell.style.margin = menus.cells.margin + 'px';
				cell.style.padding = menus.cells.padding + 'px';
				cell.style.width = menus.width / 2 + 'px';
				cell.style.borderColor = 'rgb(' + menus.cells.border.color.r + ', ' + menus.cells.border.color.g + ', ' + menus.cells.border.color.b + ')';
				cell.style.borderWidth = menus.cells.border.width + 'px';
				cell.style.borderStyle = menus.cells.border.style;
				if (j == 0) {
					cell.style.textAlign = 'right';
					if (menus[type].values[i].indexOf(' ') == 0) { // If ' ' is first character (Empty space for entire value)
						cell.style.fontWeight = 'bold';
					}
					cell.innerHTML = menus[type].options[i];
				} else if (j == 1) {
					cell.id = menus[type].options[i] + ' Cell';
					cell.style.textAlign = 'left';
					if (menus[type].values[i] == 'text') {
						let textInput = (new Text(type, i)).elt;
					} else if (menus[type].values[i] == 'number') {
						let numInput = (new Num(type, i)).elt;
						// cell.appendChild(numInput);
					} else if (menus[type].values[i] == 'list') {
						let listInput = (new List(type, i)).elt;
						// cell.appendChild(listInput);
					} else if (menus[type].values[i].indexOf('radio') != -1) { // If 'radio' is anywhere within string
						for (let k = 0; k < parseInt(menus[type].values[i]); k++) { // Creates integer of radio inputs as specified in value string
							let radioInput = (new Radio(type, i, k)).elt;
							// cell.appendChild(radioInput);
						}
					} else if (menus[type].values[i] == 'button') {
						let buttonInput = (new Button(type, i)).elt;
						// cell.appendChild(buttonInput);
					} else {
						cell.style.fontFamily = menus.text.font;
						cell.style.fontSize = menus.text.size + 'px';
						cell.innerHTML = menus[type].values[i];
					}
					if (menus[type].units[i] != undefined) {
						let unitText = document.createElement('span');
						// cell.appendChild(unitText);
						unitText.innerHTML = ' ' + menus[type].units[i];
					}
				}
			}
		}
		if (typeof menus[type].editTexts == 'function') {
			menus[type].editTexts(datA);
		}
		if (typeof menus[type].editNums == 'function') {
			menus[type].editNums(datA);
		}
		if (typeof menus[type].editLists == 'function') {
			menus[type].editLists(datA);
		}
		if (typeof menus[type].editRadios == 'function') {
			menus[type].editRadios(datA);
		}
		if (typeof menus[type].editButtons == 'function') {
			menus[type].editButtons(datA);
		}
		var button = document.createElement('button');
		content.appendChild(button);
		button.id = type + 'Button';
		button.type = 'button';
		button.style.cursor = 'pointer';
		button.style.width = menus.button.width + 'px';
		button.style.height = menus.button.height + 'px';
		button.style.position = 'relative';
		button.style.left = (window.innerWidth - menus.button.width) / 2 + 'px';
		button.style.marginTop = menus.button.top + 'px';
		button.style.backgroundColor = 'rgb(' + menus.button.backgroundColor.r + ', ' + menus.button.backgroundColor.g + ', ' + menus.button.backgroundColor.b + ')';
		button.style.borderRadius = menus.button.borderRadius + 'px';
		button.style.display = 'block';
		button.style.boxSizing = 'border-box';
		button.style.padding = '0px';
		button.style.borderWidth = '0px';
		button.style.borderBottomWidth = '2px';
		button.style.borderRaidus = '4px';
		button.style.borderColor = 'rgb(0, 0, 0)';
		button.style.outline = 'none';
		button.addEventListener('mouseover', function() {
			if (button.down != true) {
				button.style.backgroundColor = 'rgb(' + (menus.button.backgroundColor.r - 20) + ', ' + (menus.button.backgroundColor.g - 20) + ', ' + (menus.button.backgroundColor.b - 20) + ')';
			} else {
				button.style.backgroundColor = 'rgb(' + (menus.button.backgroundColor.r - 40) + ', ' + (menus.button.backgroundColor.g - 40) + ', ' + (menus.button.backgroundColor.b - 40) + ')';
			}
		});
		button.addEventListener('mouseout', function() {
			button.style.backgroundColor = 'rgb(' + menus.button.backgroundColor.r + ', ' + menus.button.backgroundColor.g + ', ' + menus.button.backgroundColor.b + ')';
		});
		button.addEventListener('mousedown', function() {
			button.style.backgroundColor = 'rgb(' + (menus.button.backgroundColor.r - 40) + ', ' + (menus.button.backgroundColor.g - 40) + ', ' + (menus.button.backgroundColor.b - 40) + ')';
			button.down = true;
		});
		button.addEventListener('mouseup', function() {
			button.style.backgroundColor = 'rgb(' + (menus.button.backgroundColor.r - 20) + ', ' + (menus.button.backgroundColor.g - 20) + ', ' + (menus.button.backgroundColor.b - 20) + ')';
			button.down = false;
		});
		button.addEventListener('click', function() {
			menus[type].submit(datA);
		});
		var buttonText = document.createElement('p');
		button.appendChild(buttonText);
		buttonText.style.margin = '0px';
		buttonText.style.padding = '0px';
		buttonText.style.color = 'rgb(' + menus.button.color.r + ', ' + menus.button.color.g + ', ' + menus.button.color.b + ')';
		buttonText.style.fontFamily = menus.button.font;
		buttonText.style.fontWeight = menus.button.weight;
		buttonText.style.fontSize = menus.button.size + 'px';
		buttonText.style.textAlign = 'center';
		buttonText.innerHTML = menus[type].button.text;
	}
	var footerDiv = document.createElement('div');
	container.appendChild(footerDiv);
	footerDiv.id = 'footerDiv';
	footerDiv.style.position = 'absolute';
	var footer = document.createElement('footer');
	footerDiv.appendChild(footer);
	footer.id = 'footer';
	footer.style.position = 'fixed';
	footer.style.bottom = '0px';
	footer.style.width = '100%';
	footer.style.height = menus.footer.height + 'px';
	footer.style.backgroundColor = 'rgb(' + menus.footer.backgroundColor.r + ', ' + menus.footer.backgroundColor.g + ', ' + menus.footer.backgroundColor.b + ')';
	footer.style.cursor = 'pointer';
	footer.addEventListener('click', function() { // Back link on footer so the entire height of the footer is link
		switch (type) {
			case 'create': {
				title.return();
				break;
			} case 'join': {
				if (game.info.host == socket.id) { // If player is host (If player is joining directly after creating the game)
					socket.emit('Game Ended', game);
					title.return();
				} else {
					renderBrowser();
				}
				break;
			} case 'respawn': {
				menus.pauseSpectate.submit();
				break;
			} case 'pauseGame': {
				menus.pauseGame.submit();
				break;
			} case 'pauseSpectate': {
				menus.pauseSpectate.submit();
				break;
			} case 'pauseTutorial': {
				menus.pauseTutorial.submit();
				break;
			}
		}
	});
	var back = document.createElement('p');
	footer.appendChild(back);
	back.style.position = 'relative';
	back.style.top = '50%';
	back.style.transform = 'translateY(-50%)';
	back.style.margin = '0px';
	back.style.marginLeft = '10px';
	back.style.color = 'rgb(' + menus.footer.color.r + ', ' + menus.footer.color.g + ', ' + menus.footer.color.b + ')';
	back.style.fontFamily = menus.footer.font;
	back.style.fontSize = menus.footer.size + 'px';
	back.innerHTML = '&larr; Back';
};

var Text = function(type, i) {
	let cell = document.getElementById('Menu Body').children[i].children[1];
	this.elt = document.createElement('input');
	cell.appendChild(this.elt);
	this.elt.id = menus[type].options[i] + ' Input';
	this.elt.style.width = menus.inputs.width + 'px';
	this.elt.style.height = menus.inputs.height + 'px';
	this.elt.type = 'text';
	this.elt.value = '';
	this.elt.style.autocomplete = 'on';
	this.elt.style.boxSizing = 'border-box';
	this.elt.style.textAlign = 'center';
	this.elt.style.fontFamily = menus.inputs.font;
	this.elt.style.fontSize = menus.inputs.size + 'px';
	this.elt.style.outline = 'none';
	this.elt.style.backgroundColor = 'rgb(255, 255, 255)';
	this.elt.style.borderWidth = '0px';
	this.elt.style.borderBottomColor = 'rgb(' + menus.inputs.border.color.r + ', ' + menus.inputs.border.color.g + ', ' + menus.inputs.border.color.b + ')';
	this.elt.style.borderBottomWidth = menus.inputs.border.width + 'px';
	this.elt.style.borderRadius = menus.inputs.border.radius + 'px';
	this.elt.addEventListener('focus', function() {
		elt = document.getElementById(menus[type].options[i] + ' Input');
		elt.style.backgroundColor = 'rgb(' + menus.inputs.backgroundColor.r + ', ' + menus.inputs.backgroundColor.g + ', ' + menus.inputs.backgroundColor.b + ')';
	});
	this.elt.addEventListener('focusout', function() {
		elt = document.getElementById(menus[type].options[i] + ' Input');
		elt.style.backgroundColor = 'rgb(255, 255, 255)';
	});
};

var Num = function(type, i) {
	let cell = document.getElementById('Menu Body').children[i].children[1];
	this.elt = document.createElement('input');
	cell.appendChild(this.elt);
	this.elt.id = menus[type].options[i] + ' Input';
	this.elt.style.width = menus.inputs.width + 'px';
	this.elt.style.height = menus.inputs.height + 'px';
	this.elt.type = 'number';
	this.elt.value = '';
	this.elt.style.autocomplete = 'on';
	this.elt.style.boxSizing = 'border-box';
	this.elt.style.textAlign = 'center';
	this.elt.style.fontFamily = menus.inputs.font;
	this.elt.style.fontSize = menus.inputs.size + 'px';
	this.elt.style.outline = 'none';
	this.elt.style.backgroundColor = 'rgb(255, 255, 255)';
	this.elt.style.borderWidth = '0px';
	this.elt.style.borderBottomColor = 'rgb(' + menus.inputs.border.color.r + ', ' + menus.inputs.border.color.g + ', ' + menus.inputs.border.color.b + ')';
	this.elt.style.borderBottomWidth = menus.inputs.border.width + 'px';
	this.elt.style.borderRadius = menus.inputs.border.radius + 'px';
	this.elt.addEventListener('focus', function() {
		elt = document.getElementById(menus[type].options[i] + ' Input');
		elt.style.backgroundColor = 'rgb(' + menus.inputs.backgroundColor.r + ', ' + menus.inputs.backgroundColor.g + ', ' + menus.inputs.backgroundColor.b + ')';
	});
	this.elt.addEventListener('focusout', function() {
		elt = document.getElementById(menus[type].options[i] + ' Input');
		elt.style.backgroundColor = 'rgb(255, 255, 255)';
	});
};

var List = function(type, i) {
	let cell = document.getElementById('Menu Body').children[i].children[1];
	this.elt = document.createElement('select');
	cell.appendChild(this.elt);
	this.elt.id = menus[type].options[i] + ' Input';
	this.elt.style.width = menus.inputs.width + 'px';
	this.elt.style.height = menus.inputs.height + 'px';
	this.elt.style.outline = 'none';
	this.elt.style.borderWidth = '0px';
	this.elt.style.borderBottomWidth = menus.inputs.border.width + 'px';
	this.elt.style.borderStyle = menus.inputs.border.style;
	this.elt.style.borderColor = 'rgb(' + menus.inputs.border.color.r + ', ' + menus.inputs.border.color.g + ', ' + menus.inputs.border.color.b + ')';
	this.elt.style.borderRadius = menus.inputs.border.radius + 'px';
	this.elt.style.fontFamily = menus.inputs.font;
	this.elt.style.fontSize = menus.inputs.size + 'px';
};

var Radio = function(type, i, k) {
	this.width = 16;
	this.height = 18;
	this.backgroundColor = { r: 255, g: 255, b: 255 };
	this.selectColor = { r: 190, g: 190, b: 190 };
	let cell = document.getElementById('Menu Body').children[i].children[1];
	this.elt = document.createElement('div');
	cell.appendChild(this.elt);
	this.elt.id = menus[type].options[i] + ' Input ' + k;
	this.elt.type = 'radio';
	this.elt.order = k;
	this.elt.value = false;
	this.elt.style.display = 'inline-block';
	this.elt.style.boxSizing = 'border-box';
	this.elt.style.position = 'relative';
	this.elt.style.top = '4px';
	this.elt.style.margin = '0px 5px 0px 5px';
	this.elt.style.width = menus.radios.width + 'px';
	this.elt.style.height = menus.radios.height + 'px';
	this.elt.style.outline = 'none';
	this.elt.style.borderWidth = '0px';
	this.elt.style.borderBottomWidth = menus.inputs.border.width + 'px';
	this.elt.style.borderStyle = menus.inputs.border.style;
	this.elt.style.borderColor = 'rgb(' + menus.inputs.border.color.r + ', ' + menus.inputs.border.color.g + ', ' + menus.inputs.border.color.b + ')';
	this.elt.style.borderRadius = menus.inputs.border.radius + 'px';
	this.elt.style.backgroundColor = 'rgb(' + menus.radios.backgroundColor.r + ', ' + menus.radios.backgroundColor.g + ', ' + menus.radios.backgroundColor.b + ')';
	this.elt.addEventListener('click', function() {
		elt = document.getElementById(menus[type].options[i] + ' Input ' + k);
		elt.value = !elt.value;
		if (elt.value == false) {
			elt.style.backgroundColor = 'rgb(' + menus.radios.backgroundColor.r + ', ' + menus.radios.backgroundColor.g + ', ' + menus.radios.backgroundColor.b + ')';
		} else if (elt.value == true) {
			elt.style.backgroundColor = 'rgb(' + menus.radios.selectColor.r + ', ' + menus.radios.selectColor.g + ', ' + menus.radios.selectColor.b + ')';
		}
		for (let l = 0; l < parseInt(menus[type].values[i]); l++) {
			if (l == elt.order) {
				continue;
			}
			let other = document.getElementById(menus[type].options[i] + ' Input ' + l);
			other.value = false;
			other.style.backgroundColor = 'rgb(' + menus.radios.backgroundColor.r + ', ' + menus.radios.backgroundColor.g + ', ' + menus.radios.backgroundColor.b + ')';
		}
	});
	let lineBreak = document.createElement('div');
	cell.appendChild(lineBreak);
	lineBreak.style.display = 'block';
	if (k + 1 < parseInt(menus[type].values[i])) { // All but last
		lineBreak.style.height = '2px';
	} else { // Last
		lineBreak.style.height = '6px';
	}
};

var Button = function(type, i) {
	this.backgroundColor = { r: 240, g: 240, b: 240 };
	this.border = menus.inputs.border;
	this.border = menus.inputs.border;
	let cell = document.getElementById('Menu Body').children[i].children[1];
	this.elt = document.createElement('button');
	cell.appendChild(this.elt);
	this.elt.id = menus[type].options[i] + ' Input';
	this.elt.type = 'button';
	this.elt.style.cursor = 'pointer';
	this.elt.style.position = 'relative';
	this.elt.style.top = '2px';
	this.elt.style.width = 45 + 'px';
	this.elt.style.height = (menus.radios.height + 4) + 'px';
	this.elt.style.outline = 'none';
	this.elt.style.padding = '0px';
	this.elt.style.boxSizing = 'border-box';
	this.elt.style.borderWidth = '0px';
	this.elt.style.borderBottomWidth = this.border.width + 'px';
	this.elt.style.borderStyle = this.border.style;
	this.elt.style.borderColor = 'rgb(' + this.border.color.r + ', ' + this.border.color.g + ', ' + this.border.color.b + ')';
	this.elt.style.borderRadius = this.border.radius + 'px';
	this.elt.backgroundColor = { r: 240, g: 240, b: 240 };
	this.elt.style.backgroundColor = 'rgb(' + this.backgroundColor.r + ', ' + this.backgroundColor.g + ', ' + this.backgroundColor.b + ')';
	this.elt.addEventListener('mouseover', function() {
		elt = document.getElementById(menus[type].options[i] + ' Input');
		if (elt.down != true) {
			elt.style.backgroundColor = 'rgb(' + (elt.backgroundColor.r - 20) + ', ' + (elt.backgroundColor.g - 20) + ', ' + (elt.backgroundColor.b - 20) + ')';
		} else {
			elt.style.backgroundColor = 'rgb(' + (elt.backgroundColor.r - 40) + ', ' + (elt.backgroundColor.g - 40) + ', ' + (elt.backgroundColor.b - 40) + ')';
		}
	});
	this.elt.addEventListener('mouseout', function() {
		elt = document.getElementById(menus[type].options[i] + ' Input');
		elt.style.backgroundColor = 'rgb(' + elt.backgroundColor.r + ', ' + elt.backgroundColor.g + ', ' + elt.backgroundColor.b + ')';
	});
	this.elt.addEventListener('mousedown', function() {
		elt = document.getElementById(menus[type].options[i] + ' Input');
		elt.style.backgroundColor = 'rgb(' + (elt.backgroundColor.r - 40) + ', ' + (elt.backgroundColor.g - 40) + ', ' + (elt.backgroundColor.b - 40) + ')';
		elt.down = true;
	});
	this.elt.addEventListener('mouseup', function() {
		elt = document.getElementById(menus[type].options[i] + ' Input');
		elt.style.backgroundColor = 'rgb(' + (elt.backgroundColor.r - 20) + ', ' + (elt.backgroundColor.g - 20) + ', ' + (elt.backgroundColor.b - 20) + ')';
		elt.down = false;
	});
};